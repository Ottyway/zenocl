package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Crits;
import dev.zenocl.util.Inv;
import dev.zenocl.util.Rotations;
import dev.zenocl.util.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class KillAura extends Module {
    private final NumSetting range = add(new NumSetting("Range", 3.0, 1.0, 6.0, 0.1));
    private final NumSetting fov = add(new NumSetting("FOV", 360, 30, 360, 10));
    private final NumSetting turn = add(new NumSetting("TurnSpeed", 90, 10, 180, 5));
    private final ModeSetting priority = add(new ModeSetting("Priority", "Distance", "Distance", "Health"));
    private final ModeSetting crits = add(new ModeSetting("Crits", "Off", "Off", "Falling", "Jump"));
    private final BoolSetting cooldown = add(new BoolSetting("Cooldown", true));
    private final BoolSetting sprintReset = add(new BoolSetting("SprintReset", true));
    private final BoolSetting autoWeapon = add(new BoolSetting("AutoWeapon", true));
    private final BoolSetting shieldBreak = add(new BoolSetting("ShieldBreak", true));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    private final BoolSetting invisible = add(new BoolSetting("Invisible", true));

    public KillAura() {
        super("KillAura", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (mc().currentScreen != null) {
            return;
        }
        LivingEntity t = Targets.pick(range.get(), players.get(), mobs.get(), invisible.get(), priority.is("Health"), fov.get());
        if (t == null) {
            return;
        }
        Targets.mark(t);
        Rotations.face(p, t.getEntityPos().add(0, t.getHeight() * 0.65, 0), turn.getFloat());
        pickWeapon(p, t);

        boolean ready = !cooldown.get() || p.getAttackCooldownProgress(0.5f) >= 0.93f;
        if (!ready) {
            return;
        }

        // Крит-режимы: Falling ждёт падения, Jump сам прыгает с земли и бьёт в падении
        if (!crits.is("Off")) {
            if (crits.is("Jump") && p.isOnGround() && !p.isSneaking()) {
                p.jump();
                return;
            }
            if (!Crits.canCrit(p)) {
                return;
            }
            Crits.unsprint(p);
        } else if (sprintReset.get()) {
            Crits.unsprint(p);
        }

        mc().interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }

    private void pickWeapon(ClientPlayerEntity p, LivingEntity t) {
        int slot = -1;
        if (shieldBreak.get() && t instanceof PlayerEntity pl && pl.isBlocking()) {
            slot = Inv.findBestHotbar(p, "_axe");
        }
        if (slot < 0 && autoWeapon.get() && !Inv.isWeapon(p.getMainHandStack())) {
            slot = Inv.findBestHotbar(p, "_sword");
            if (slot < 0) {
                slot = Inv.findBestHotbar(p, "_axe");
            }
        }
        if (slot >= 0 && slot != p.getInventory().getSelectedSlot()) {
            p.getInventory().setSelectedSlot(slot);
        }
    }
}
