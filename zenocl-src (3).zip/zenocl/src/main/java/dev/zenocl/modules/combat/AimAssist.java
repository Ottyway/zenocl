package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Rotations;
import dev.zenocl.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

public class AimAssist extends Module {
    private final NumSetting range = add(new NumSetting("Range", 4.5, 1.0, 8.0, 0.1));
    private final NumSetting speed = add(new NumSetting("Speed", 25, 2, 90, 1));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));

    public AimAssist() {
        super("AimAssist", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc().currentScreen != null) {
            return;
        }
        LivingEntity t = Targets.nearest(range.get(), players.get(), mobs.get(), false);
        if (t == null) {
            return;
        }
        Targets.mark(t);
        Rotations.face(mc().player, t.getEntityPos().add(0, t.getHeight() * 0.7, 0), speed.getFloat());
    }
}
