package dev.zenocl.command;

import dev.zenocl.core.Module;
import dev.zenocl.core.ModuleManager;
import dev.zenocl.core.Setting;
import dev.zenocl.gui.ClickGui;
import dev.zenocl.hud.Theme;
import dev.zenocl.modules.misc.ClientSettings;
import dev.zenocl.util.Friends;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Чат-команды: .bind add "KillAura" "R", .toggle, .set, .theme, .config и т.д. */
public final class Commands {
    private static final Pattern TOKEN = Pattern.compile("\"([^\"]*)\"|(\\S+)");

    private Commands() {
    }

    /** true = сообщение было командой и в чат не уходит. */
    public static boolean handle(String raw) {
        ClientSettings cs = ClientSettings.INSTANCE;
        String prefix = cs != null ? cs.prefix.get() : ".";
        if (!raw.startsWith(prefix) || raw.startsWith(prefix + prefix)) {
            return false;
        }
        List<String> a = tokens(raw.substring(prefix.length()));
        if (a.isEmpty()) {
            return true;
        }
        try {
            run(a);
        } catch (RuntimeException e) {
            say("§cОшибка команды: " + e.getMessage());
        }
        return true;
    }

    private static void run(List<String> a) {
        String cmd = a.get(0).toLowerCase();
        switch (cmd) {
            case "help", "?" -> help();
            case "bind", "b" -> bind(a);
            case "toggle", "t" -> {
                Module m = module(arg(a, 1, "toggle <модуль>"));
                if (!m.isSettingsOnly()) {
                    m.toggle();
                    say(m.name + (m.isEnabled() ? " §aвключён" : " §cвыключен"));
                }
            }
            case "set" -> set(a);
            case "settings", "s" -> {
                Module m = module(arg(a, 1, "settings <модуль>"));
                StringBuilder sb = new StringBuilder("§7Настройки " + m.name + ": ");
                for (Setting<?> s : m.settings) {
                    sb.append("§f").append(s.name).append("§7=").append(s.serialize()).append("  ");
                }
                say(sb.toString());
            }
            case "friend", "f" -> friend(a);
            case "theme" -> theme(a);
            case "config", "cfg" -> {
                String sub = arg(a, 1, "config save|load");
                if (sub.equalsIgnoreCase("save")) {
                    ModuleManager.save();
                    say("§aКонфиг сохранён");
                } else if (sub.equalsIgnoreCase("load")) {
                    ModuleManager.load();
                    say("§aКонфиг загружен");
                } else {
                    say("§7Использование: config save|load");
                }
            }
            case "modules", "list" -> {
                StringBuilder sb = new StringBuilder("§7Модули: ");
                for (Module m : ModuleManager.all()) {
                    sb.append(m.isEnabled() ? "§a" : "§f").append(m.name).append("§7, ");
                }
                say(sb.toString());
            }
            default -> say("§cНеизвестная команда. §7Напиши help");
        }
    }

    private static void help() {
        say("§dZenoCL §7- команды:");
        say("§f bind add \"модуль\" \"клавиша\" §7- назначить бинд (пример: bind add KillAura R)");
        say("§f bind remove \"модуль\" §7| §fbind list §7| §fbind clear");
        say("§f toggle <модуль> §7(или t)  §f set <модуль> <настройка> <значение>");
        say("§f friend add|remove <ник> §7(без ника - игрок под прицелом)  §ffriend list|clear");
        say("§f settings <модуль>  §fmodules  §ftheme <имя|list>  §fconfig save|load");
    }

    private static void bind(List<String> a) {
        String sub = arg(a, 1, "bind add|remove|list|clear").toLowerCase();
        switch (sub) {
            case "add" -> {
                Module m = module(arg(a, 2, "bind add \"модуль\" \"клавиша\""));
                int key = parseKey(arg(a, 3, "bind add \"модуль\" \"клавиша\""));
                m.setKey(key);
                say(m.name + " §7привязан к §d" + ClickGui.keyName(key));
            }
            case "remove", "del" -> {
                Module m = module(arg(a, 2, "bind remove \"модуль\""));
                m.setKey(0);
                say("§7Бинд " + m.name + " удалён");
            }
            case "clear" -> {
                for (Module m : ModuleManager.all()) {
                    m.setKey(0);
                }
                say("§7Все бинды очищены");
            }
            case "list" -> {
                boolean any = false;
                for (Module m : ModuleManager.all()) {
                    if (m.getKey() != 0) {
                        say("§f" + m.name + " §7-> §d" + ClickGui.keyName(m.getKey()));
                        any = true;
                    }
                }
                if (!any) {
                    say("§7Биндов нет");
                }
            }
            default -> say("§7Использование: bind add|remove|list|clear");
        }
    }

    private static void set(List<String> a) {
        Module m = module(arg(a, 1, "set <модуль> <настройка> <значение>"));
        String name = arg(a, 2, "set <модуль> <настройка> <значение>");
        String value = arg(a, 3, "set <модуль> <настройка> <значение>");
        for (Setting<?> s : m.settings) {
            if (norm(s.name).equals(norm(name))) {
                String v = value;
                if (v.equalsIgnoreCase("on") || v.equals("1")) {
                    v = "true";
                } else if (v.equalsIgnoreCase("off") || v.equals("0")) {
                    v = "false";
                }
                s.deserialize(v);
                say("§7" + m.name + "." + s.name + " = §d" + s.serialize());
                return;
            }
        }
        say("§cНет настройки " + name + ". §7Смотри: settings " + m.name);
    }

    private static void friend(List<String> a) {
        String sub = arg(a, 1, "friend add|remove|list|clear").toLowerCase();
        switch (sub) {
            case "add", "remove", "del" -> {
                String name = a.size() > 2 ? a.get(2) : null;
                if (name == null && MinecraftClient.getInstance().targetedEntity instanceof net.minecraft.entity.player.PlayerEntity pl) {
                    name = pl.getName().getString();
                }
                if (name == null) {
                    throw new IllegalArgumentException("укажи ник или наведись на игрока");
                }
                if (sub.equals("add")) {
                    Friends.add(name);
                    say("§a" + name + " §7добавлен в друзья");
                } else {
                    Friends.remove(name);
                    say("§7" + name + " удалён из друзей");
                }
            }
            case "clear" -> {
                Friends.clear();
                say("§7Список друзей очищен");
            }
            case "list" -> say("§7Друзья: §f" + (Friends.all().isEmpty() ? "нет" : String.join(", ", Friends.all())));
            default -> say("§7Использование: friend add|remove|list|clear");
        }
    }

    private static void theme(List<String> a) {
        ClientSettings cs = ClientSettings.INSTANCE;
        String n = arg(a, 1, "theme <имя|list>");
        if (n.equalsIgnoreCase("list")) {
            say("§7Темы: §f" + String.join(", ", Theme.names()));
            return;
        }
        cs.theme.deserialize(n);
        say("§7Тема: §d" + cs.theme.get());
    }

    // ---- утилиты ----

    private static String norm(String s) {
        return s.replace(" ", "").replace("_", "").toLowerCase();
    }

    private static Module module(String name) {
        String n = norm(name);
        for (Module m : ModuleManager.all()) {
            if (norm(m.name).equals(n)) {
                return m;
            }
        }
        throw new IllegalArgumentException("нет модуля \"" + name.trim() + "\" (список: modules)");
    }

    private static String arg(List<String> a, int i, String usage) {
        if (i >= a.size()) {
            throw new IllegalArgumentException("мало аргументов. Использование: " + usage);
        }
        return a.get(i);
    }

    static int parseKey(String raw) {
        String s = raw.trim();
        if (s.equalsIgnoreCase("none")) {
            return 0;
        }
        if (s.length() == 1) {
            char c = Character.toUpperCase(s.charAt(0));
            if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) {
                return c;
            }
        }
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            if (ClickGui.keyName(k).equalsIgnoreCase(s)) {
                return k;
            }
        }
        throw new IllegalArgumentException("не знаю клавишу \"" + s + "\" (примеры: R, F6, RSHIFT, SPACE)");
    }

    private static List<String> tokens(String s) {
        List<String> out = new ArrayList<>();
        Matcher m = TOKEN.matcher(s);
        while (m.find()) {
            out.add(m.group(1) != null ? m.group(1) : m.group(2));
        }
        return out;
    }

    static void say(String msg) {
        ClientSettings cs = ClientSettings.INSTANCE;
        if (cs != null && !cs.chatFeedback.get()) {
            return;
        }
        var p = MinecraftClient.getInstance().player;
        if (p != null) {
            p.sendMessage(Text.literal("§d[ZenoCL] §f" + msg), false);
        }
    }
}
