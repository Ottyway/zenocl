package dev.zenocl.core;

import dev.zenocl.hud.HudModule;
import dev.zenocl.modules.combat.AimAssist;
import dev.zenocl.modules.combat.AutoCrystal;
import dev.zenocl.modules.combat.AutoGapple;
import dev.zenocl.modules.combat.AutoTotem;
import dev.zenocl.modules.combat.KillAura;
import dev.zenocl.modules.combat.TriggerBot;
import dev.zenocl.modules.combat.Velocity;
import dev.zenocl.modules.misc.AntiAFK;
import dev.zenocl.modules.misc.ClientSettings;
import dev.zenocl.modules.movement.Fly;
import dev.zenocl.modules.movement.Glide;
import dev.zenocl.modules.movement.Speed;
import dev.zenocl.modules.movement.TargetStrafe;
import dev.zenocl.modules.movement.Sprint;
import dev.zenocl.modules.player.AutoArmor;
import dev.zenocl.modules.player.AutoRespawn;
import dev.zenocl.modules.player.FastPlace;
import dev.zenocl.modules.visual.ArmorHud;
import dev.zenocl.modules.visual.ESP;
import dev.zenocl.modules.visual.Fullbright;
import dev.zenocl.modules.visual.InfoHud;
import dev.zenocl.modules.visual.InventoryHud;
import dev.zenocl.modules.visual.ModuleList;
import dev.zenocl.modules.visual.NotificationsHud;
import dev.zenocl.modules.visual.PotionsHud;
import dev.zenocl.modules.visual.TargetInfo;
import dev.zenocl.modules.visual.Watermark;
import dev.zenocl.util.Friends;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("zenocl.properties");

    private ModuleManager() {
    }

    public static void init() {
        // Combat
        MODULES.add(new KillAura());
        MODULES.add(new TriggerBot());
        MODULES.add(new AimAssist());
        MODULES.add(new AutoCrystal());
        MODULES.add(new AutoTotem());
        MODULES.add(new AutoGapple());
        MODULES.add(new Velocity());
        // Movement
        MODULES.add(new Sprint());
        MODULES.add(new Speed());
        MODULES.add(new Fly());
        MODULES.add(new Glide());
        MODULES.add(new TargetStrafe());
        // Visual
        MODULES.add(new ESP());
        MODULES.add(new Fullbright());
        MODULES.add(new Watermark());
        MODULES.add(new ModuleList());
        MODULES.add(new NotificationsHud());
        MODULES.add(new TargetInfo());
        MODULES.add(new InventoryHud());
        MODULES.add(new ArmorHud());
        MODULES.add(new InfoHud());
        MODULES.add(new PotionsHud());
        // Player
        MODULES.add(new FastPlace());
        MODULES.add(new AutoRespawn());
        MODULES.add(new AutoArmor());
        // Misc
        MODULES.add(new AntiAFK());
        MODULES.add(new ClientSettings());

        boolean first = !Files.exists(CONFIG);
        load();

        // Первый запуск: HUD включён сразу
        if (first) {
            for (Module m : MODULES) {
                if (m instanceof HudModule) {
                    m.loadEnabled(true);
                }
            }
            get(InventoryHud.class).loadEnabled(false);
            get(PotionsHud.class).loadEnabled(false);
        }
    }

    public static List<Module> all() {
        return MODULES;
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.category == c) {
                out.add(m);
            }
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> cls) {
        for (Module m : MODULES) {
            if (m.getClass() == cls) {
                return (T) m;
            }
        }
        throw new IllegalStateException("Module not registered: " + cls);
    }

    public static boolean isOn(Class<? extends Module> cls) {
        for (Module m : MODULES) {
            if (m.getClass() == cls) {
                return m.isEnabled();
            }
        }
        return false;
    }

    /** Вызывается каждый клиентский тик. */
    public static void tick(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();

        for (Module m : MODULES) {
            int key = m.getKey();
            if (key != 0) {
                boolean down = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
                if (down && !m.keyWasDown && mc.currentScreen == null) {
                    m.toggle();
                }
                m.keyWasDown = down;
            }
        }

        if (mc.player == null || mc.world == null) {
            return;
        }

        for (Module m : MODULES) {
            if (m.isEnabled()) {
                m.onTick();
            }
        }
    }

    public static void load() {
        if (!Files.exists(CONFIG)) {
            return;
        }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(CONFIG, StandardCharsets.UTF_8)) {
            p.load(r);
        } catch (IOException e) {
            return;
        }
        Friends.load(p.getProperty("friends", ""));
        for (Module m : MODULES) {
            String base = m.name + ".";
            if (p.containsKey(base + "enabled")) {
                m.loadEnabled(Boolean.parseBoolean(p.getProperty(base + "enabled")));
            }
            if (p.containsKey(base + "key")) {
                try {
                    m.setKey(Integer.parseInt(p.getProperty(base + "key")));
                } catch (NumberFormatException ignored) {
                }
            }
            for (Setting<?> s : m.settings) {
                String v = p.getProperty(base + s.name);
                if (v != null) {
                    s.deserialize(v);
                }
            }
        }
    }

    public static void save() {
        Properties p = new Properties();
        for (Module m : MODULES) {
            String base = m.name + ".";
            p.setProperty(base + "enabled", Boolean.toString(m.isEnabled()));
            p.setProperty(base + "key", Integer.toString(m.getKey()));
            for (Setting<?> s : m.settings) {
                p.setProperty(base + s.name, s.serialize());
            }
        }
        p.setProperty("friends", Friends.serialize());
        try {
            Files.createDirectories(CONFIG.getParent());
            try (Writer w = Files.newBufferedWriter(CONFIG, StandardCharsets.UTF_8)) {
                p.store(w, "ZenoCL config");
            }
        } catch (IOException ignored) {
        }
    }
}
