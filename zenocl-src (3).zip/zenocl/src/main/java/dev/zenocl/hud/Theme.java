package dev.zenocl.hud;

import dev.zenocl.modules.misc.ClientSettings;

/** Цветовые темы клиента: два цвета градиента. Rainbow считается отдельно. */
public final class Theme {
    public record T(String name, int a, int b) {
    }

    private static final T[] ALL = {
            new T("Crimson", 0xFFE0143C, 0xFF8A0F24),
            new T("Violet", 0xFF8A5CFF, 0xFF4CC9F0),
            new T("Ocean", 0xFF2F80ED, 0xFF56CCF2),
            new T("Sunset", 0xFFFF512F, 0xFFF09819),
            new T("Emerald", 0xFF11998E, 0xFF38EF7D),
            new T("Rose", 0xFFFF5F9E, 0xFFB06AB3),
            new T("Blood", 0xFFE53935, 0xFF8E0E00),
            new T("Mono", 0xFFFFFFFF, 0xFF8A8A99),
            new T("Rainbow", 0, 0)
    };

    private Theme() {
    }

    public static T[] all() {
        return ALL;
    }

    /** Очень тёмный оттенок цвета темы для фонов (f ~ 0.05..0.2). Возвращает RGB без альфы. */
    public static int dark(float f) {
        T t = current();
        int c = rainbow(t) ? Render.accent(0) : t.a();
        int r = Math.min(255, (int) (((c >> 16) & 0xFF) * f));
        int g = Math.min(255, (int) (((c >> 8) & 0xFF) * f));
        int b = Math.min(255, (int) ((c & 0xFF) * f));
        return (r << 16) | (g << 8) | b;
    }

    public static String[] names() {
        String[] n = new String[ALL.length];
        for (int i = 0; i < ALL.length; i++) {
            n[i] = ALL[i].name();
        }
        return n;
    }

    public static T current() {
        ClientSettings cs = ClientSettings.INSTANCE;
        if (cs != null) {
            for (T t : ALL) {
                if (t.name().equalsIgnoreCase(cs.theme.get())) {
                    return t;
                }
            }
        }
        return ALL[0];
    }

    public static boolean rainbow(T t) {
        return t.name().equals("Rainbow");
    }

    /** HSV -> ARGB без java.awt. */
    public static int hsv(float h, float s, float v) {
        float r = 0, g = 0, b = 0;
        int i = (int) (h * 6);
        float f = h * 6 - i;
        float p = v * (1 - s), q = v * (1 - f * s), t = v * (1 - (1 - f) * s);
        switch (i % 6) {
            case 0 -> { r = v; g = t; b = p; }
            case 1 -> { r = q; g = v; b = p; }
            case 2 -> { r = p; g = v; b = t; }
            case 3 -> { r = p; g = q; b = v; }
            case 4 -> { r = t; g = p; b = v; }
            default -> { r = v; g = p; b = q; }
        }
        return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
    }
}
