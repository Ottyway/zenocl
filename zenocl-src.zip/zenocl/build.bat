@echo off
chcp 65001 >nul
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo Java ne naiden. Ustanovi JDK 21: https://adoptium.net/temurin/releases/?version=21
  pause
  exit /b 1
)
call gradlew.bat build --no-daemon
if errorlevel 1 (
  echo.
  echo SBORKA NE UDALAS - skopiruj stroki s "error:" i otprav Claude
  pause
  exit /b 1
)
echo.
echo GOTOVO: jar lezhit v papke build\libs  (fail zenocl-1.0.0.jar, BEZ -sources)
explorer build\libs
pause
