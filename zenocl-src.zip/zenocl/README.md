# ZenoCL — HvH client for Minecraft 1.21.11 (Fabric)

## Управление
- **Right Shift** — ClickGUI. ЛКМ вкл/выкл, ПКМ или `...` — настройки, СКМ — бинд (Backspace снимает).
- **Чат-команды** (префикс по умолчанию `.`, меняется в Client -> Prefix):
  - `.bind add "KillAura" "R"` — назначить бинд (кавычки необязательны)
  - `.bind remove "KillAura"` · `.bind list` · `.bind clear`
  - `.toggle KillAura` (или `.t`) · `.modules`
  - `.settings TargetStrafe` — показать настройки · `.set TargetStrafe Radius 3`
  - `.friend add Ник` (или наведись на игрока и `.friend add`) · `.friend remove|list|clear` — друзей не бьют
  - `.theme list` · `.theme Sunset` · `.config save|load` · `.help`

## Как получить .jar
### Вариант 1: GitHub Actions (без установки чего-либо)
1. Создай репозиторий на github.com (New repository).
2. Загрузи ВСЁ содержимое папки `zenocl` в корень репозитория вместе со скрытой папкой `.github`
   (проще всего через git: `git init && git add . && git commit -m init && git branch -M main && git remote add origin <url> && git push -u origin main`).
3. Вкладка **Actions** -> `build` -> дождись зелёной галочки (3-6 минут).
4. Открой запуск -> внизу **Artifacts** -> `ZenoCL-jar` -> скачай zip -> внутри `zenocl-1.0.0.jar`.

### Вариант 2: на своём ПК
Нужны JDK 21 и Gradle 9: `gradle build` -> `build/libs/zenocl-1.0.0.jar`.

### Установка
Fabric Loader 0.18.2+ и Fabric API 0.141.3+1.21.11, jar в папку `mods`.
(Файл `zenocl-1.0.0-sources.jar`, если появится рядом, ставить не нужно.)

## Шрифт и лицензия
HUD использует шрифт Inter (SIL OFL 1.1), лицензия лежит в `assets/zenocl/font/INTER-LICENSE.txt`.
Выключить: Client -> InterFont (если шрифт не загрузился, клиент сам вернётся к стандартному).

## Новое
- Плавный скролл, анимации переключателей, окна и страниц в ClickGUI.
- 24 новых модуля: Jesus, Spider, Step, Bhop, Strafe, HighJump, AirJump, FastFall, AntiVoid, AutoWalk, AntiBot, Surround, AutoLog, ChestStealer, MiddleClickFriend, AutoEat, AutoSneak, AutoMine, Spammer, Panic, Keystrokes, CPS, Radar, Session.
- Новые настройки комбата: AimPoint, Jitter, HitChance, ThroughWalls (KillAura); FOV, AimPoint, OnlyClick (AimAssist); Cooldown, HitChance (TriggerBot).
- Ещё 6 модулей: AutoPot, AutoXP, BowAim, PearlThrow, NoFall, Zoom. Тема Custom (цвета в настройках Client), профили `.config save|load <имя>`, команда `.panic`, анимация закрытия меню.
