package dev.zenocl.mixin;

import dev.zenocl.util.SilentRot;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** На время отправки пакета движения подставляет тихие углы, затем возвращает настоящие. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Unique
    private float zenocl$realYaw;
    @Unique
    private float zenocl$realPitch;
    @Unique
    private boolean zenocl$swapped;

    // require = 0: если метод в этой версии называется иначе, игра не падает, а тихие ротации просто не работают
    @Inject(method = "sendMovementPackets", at = @At("HEAD"), require = 0)
    private void zenocl$swapIn(CallbackInfo ci) {
        zenocl$swapped = SilentRot.active();
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        SilentRot.sent(zenocl$swapped ? SilentRot.yaw() : self.getYaw(), zenocl$swapped ? SilentRot.pitch() : self.getPitch());
        if (zenocl$swapped) {
            zenocl$realYaw = self.getYaw();
            zenocl$realPitch = self.getPitch();
            self.setYaw(SilentRot.yaw());
            self.setPitch(SilentRot.pitch());
        }
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"), require = 0)
    private void zenocl$swapOut(CallbackInfo ci) {
        if (zenocl$swapped) {
            ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
            self.setYaw(zenocl$realYaw);
            self.setPitch(zenocl$realPitch);
            zenocl$swapped = false;
            SilentRot.consume();
        }
    }
}
