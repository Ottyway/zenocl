package dev.zenocl.hud;

import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Вращающаяся переливающаяся 3D-буква Z, нарисованная программно (прямоугольники построчно).
 * Модель: три выпуклые призмы (верхняя и нижняя планки + диагональ), поворот вокруг оси Y,
 * перспектива, отсечение невидимых граней, освещение, перелив цвета темы и блик, свечение и искры.
 */
public final class Icon3D {
    private static final double T = 0.24;      // толщина планок
    private static final double W = 0.36;      // горизонтальная толщина диагонали
    private static final double DEPTH = 0.17;  // половина глубины выдавливания
    private static final double CAM = 3.2;     // расстояние камеры (перспектива)

    private static final double[][][] PARTS = {
            {{-0.5, -0.5}, {0.5, -0.5}, {0.5, -0.5 + T}, {-0.5, -0.5 + T}},
            {{0.5 - W, -0.5 + T}, {0.5, -0.5 + T}, {-0.5 + W, 0.5 - T}, {-0.5, 0.5 - T}},
            {{-0.5, 0.5 - T}, {0.5, 0.5 - T}, {0.5, 0.5}, {-0.5, 0.5}}
    };

    // направление света (нормализовано)
    private static final double LX = -0.38, LY = -0.52, LZ = 0.76;

    private Icon3D() {
    }

    private record Face(double[] x, double[] y, double avgZ, float lum) {
    }

    /** cx, cy - центр иконки в пикселях GUI, size - высота, phase - сдвиг по времени (0..1). */
    public static void draw(DrawContext ctx, int cx, int cy, float size, double phase) {
        long now = System.currentTimeMillis();
        double ang = angle(((now / 1000.0) / 4.5 + phase) % 1.0);
        double cos = Math.cos(ang), sin = Math.sin(ang);

        drawGlow(ctx, cx, cy, size, now);

        List<Face> faces = new ArrayList<>();
        for (double[][] part : PARTS) {
            double[][] v = new double[8][];
            double mx = 0, my = 0;
            for (int i = 0; i < 4; i++) {
                mx += part[i][0] / 4;
                my += part[i][1] / 4;
                v[i] = rotate(part[i][0], part[i][1], DEPTH, cos, sin);
                v[4 + i] = rotate(part[i][0], part[i][1], -DEPTH, cos, sin);
            }
            double[] c = rotate(mx, my, 0, cos, sin);

            int[][] idx = {
                    {0, 1, 2, 3}, {4, 5, 6, 7},
                    {0, 1, 5, 4}, {1, 2, 6, 5}, {2, 3, 7, 6}, {3, 0, 4, 7}
            };
            for (int[] f : idx) {
                double[] a = v[f[0]], b = v[f[1]], d = v[f[2]];
                double ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2];
                double wx = d[0] - a[0], wy = d[1] - a[1], wz = d[2] - a[2];
                double nx = uy * wz - uz * wy, ny = uz * wx - ux * wz, nz = ux * wy - uy * wx;
                double len = Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (len < 1e-9) {
                    continue;
                }
                nx /= len;
                ny /= len;
                nz /= len;
                // нормаль наружу: от центра призмы к центру грани
                double fx = 0, fy = 0, fz = 0;
                for (int k : f) {
                    fx += v[k][0] / 4;
                    fy += v[k][1] / 4;
                    fz += v[k][2] / 4;
                }
                if (nx * (fx - c[0]) + ny * (fy - c[1]) + nz * (fz - c[2]) < 0) {
                    nx = -nx;
                    ny = -ny;
                    nz = -nz;
                }
                if (nz <= 0.02) {
                    continue; // грань смотрит от камеры
                }
                double[] px = new double[4], py = new double[4];
                for (int k = 0; k < 4; k++) {
                    double persp = CAM / (CAM - v[f[k]][2]);
                    px[k] = cx + v[f[k]][0] * size * persp;
                    py[k] = cy + v[f[k]][1] * size * persp;
                }
                float lum = (float) (0.42 + 0.58 * Math.max(0, nx * LX + ny * LY + nz * LZ));
                faces.add(new Face(px, py, fz, lum));
            }
        }
        faces.sort(Comparator.comparingDouble(Face::avgZ));

        double top = cy - size * 0.55;
        double sweep = ((now % 2200) / 2200.0) * size * 2.6 - size * 0.8;
        for (Face f : faces) {
            fillPoly(ctx, f, top, sweep, size, phase);
        }
        drawSparkles(ctx, cx, cy, size, now);
    }

    /** 0.6 периода вращение с плавным разгоном, затем пауза лицом к камере с лёгким покачиванием. */
    private static double angle(double t) {
        if (t < 0.6) {
            double u = t / 0.6;
            double e = u < 0.5 ? 2 * u * u : 1 - 2 * (1 - u) * (1 - u);
            return e * Math.PI * 2;
        }
        return Math.sin((t - 0.6) / 0.4 * Math.PI * 2) * 0.14;
    }

    private static double[] rotate(double x, double y, double z, double cos, double sin) {
        return new double[]{x * cos + z * sin, y, -x * sin + z * cos};
    }

    private static void fillPoly(DrawContext ctx, Face f, double top, double sweep, float size, double phase) {
        double minY = Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (double y : f.y()) {
            minY = Math.min(minY, y);
            maxY = Math.max(maxY, y);
        }
        int y0 = (int) Math.floor(minY), y1 = (int) Math.ceil(maxY);
        for (int y = y0; y < y1; y++) {
            double yc = y + 0.5;
            double lo = Double.MAX_VALUE, hi = -Double.MAX_VALUE;
            for (int i = 0; i < 4; i++) {
                int j = (i + 1) & 3;
                double ay = f.y()[i], by = f.y()[j];
                if ((ay <= yc && by > yc) || (by <= yc && ay > yc)) {
                    double x = f.x()[i] + (yc - ay) / (by - ay) * (f.x()[j] - f.x()[i]);
                    lo = Math.min(lo, x);
                    hi = Math.max(hi, x);
                }
            }
            if (hi < lo) {
                continue;
            }
            int xa = (int) Math.floor(lo), xb = (int) Math.ceil(hi);
            if (xb <= xa) {
                xb = xa + 1;
            }
            // переливающийся цвет темы по вертикали + бегущий блик
            int base = Render.accent(y * 0.2 + phase * 6.0);
            double k = Math.max(0, 1 - Math.abs((y - top) - sweep) / (size * 0.2));
            int col = Render.lerp(base, 0xFFFFFFFF, (float) (k * 0.8));
            ctx.fill(xa, y, xb, y + 1, shade(col, f.lum()));
        }
    }

    private static int shade(int c, float f) {
        int r = Math.min(255, (int) (((c >> 16) & 0xFF) * f));
        int g = Math.min(255, (int) (((c >> 8) & 0xFF) * f));
        int b = Math.min(255, (int) ((c & 0xFF) * f));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static void drawGlow(DrawContext ctx, int cx, int cy, float size, long now) {
        double pulse = 0.75 + 0.25 * Math.sin(now / 500.0);
        for (int i = 0; i < 4; i++) {
            int r = (int) (size * (0.62 + 0.2 * i) * pulse);
            Render.rrect(ctx, cx - r, cy - r, r * 2, r * 2, Render.withAlpha(Render.accent(i * 0.6), 0.07f));
        }
    }

    private static void drawSparkles(DrawContext ctx, int cx, int cy, float size, long now) {
        for (int i = 0; i < 4; i++) {
            double a = now / 900.0 + i * 1.7;
            int px = (int) (cx + Math.cos(a * (0.8 + 0.15 * i)) * size * 0.85);
            int py = (int) (cy + Math.sin(a * 1.3 + i) * size * 0.7);
            double pulse = (Math.sin(a * 3) + 1) / 2;
            int col = Render.withAlpha(0xFFFFFFFF, (float) (0.25 + 0.75 * pulse));
            ctx.fill(px - 1, py, px + 2, py + 1, col);
            ctx.fill(px, py - 1, px + 1, py + 2, col);
        }
    }
}
