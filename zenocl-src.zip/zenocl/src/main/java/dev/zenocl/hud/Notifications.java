package dev.zenocl.hud;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Плашки "Module ON/OFF" в правом нижнем углу. */
public final class Notifications {
    public static final long LIFETIME_MS = 2200;
    public static final List<Note> ACTIVE = new ArrayList<>();

    private Notifications() {
    }

    public static final class Note {
        public final String module;
        public final boolean on;
        public final long born = System.currentTimeMillis();

        Note(String module, boolean on) {
            this.module = module;
            this.on = on;
        }

        public long age() {
            return System.currentTimeMillis() - born;
        }
    }

    public static void push(String module, boolean on) {
        var cs = dev.zenocl.modules.misc.ClientSettings.INSTANCE;
        if (cs != null && !cs.notifications.get()) {
            return;
        }
        ACTIVE.removeIf(n -> n.module.equals(module));
        ACTIVE.add(new Note(module, on));
        if (ACTIVE.size() > 6) {
            ACTIVE.remove(0);
        }
    }

    public static void cleanup() {
        Iterator<Note> it = ACTIVE.iterator();
        while (it.hasNext()) {
            if (it.next().age() > LIFETIME_MS) {
                it.remove();
            }
        }
    }
}
