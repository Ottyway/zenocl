package dev.zenocl.hud;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import net.minecraft.client.gui.DrawContext;

/** Модуль, который что-то рисует на экране. Живёт в категории Visual. */
public abstract class HudModule extends Module {
    protected HudModule(String name) {
        super(name, Category.VISUAL);
    }

    public abstract void render(DrawContext ctx, int sw, int sh);
}
