package dev.zenocl.hud;

import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Текст с кастомным шрифтом Inter (assets/zenocl/font/main.json).
 * Если после обновления Minecraft сломается компиляция - править нужно только эту строку.
 */
public final class FontText {
    private static final Style STYLE = Style.EMPTY.withFont(new StyleSpriteSource.Font(Identifier.of("zenocl", "main")));

    private FontText() {
    }

    public static Text of(String s) {
        return Text.literal(s).setStyle(STYLE);
    }
}
