package dev.zenocl.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Targets {
    /** Последняя цель боевых модулей (для TargetInfo). */
    public static LivingEntity current;
    public static long currentStamp;

    private Targets() {
    }

    public static void mark(LivingEntity e) {
        current = e;
        currentStamp = System.currentTimeMillis();
    }

    public static LivingEntity recent() {
        if (current != null && current.isAlive() && System.currentTimeMillis() - currentStamp < 3000) {
            return current;
        }
        return null;
    }

    public static boolean valid(LivingEntity e, boolean players, boolean mobs, boolean invisible) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (e == mc.player || !e.isAlive()) {
            return false;
        }
        if (!invisible && e.isInvisible()) {
            return false;
        }
        if (e instanceof PlayerEntity pl) {
            return players && !Friends.is(pl.getName().getString()) && !dev.zenocl.modules.combat.AntiBot.isBot(pl);
        }
        return mobs && e instanceof MobEntity;
    }

    public static LivingEntity nearest(double range, boolean players, boolean mobs, boolean invisible) {
        return pick(range, players, mobs, invisible, false, 360);
    }

    /**
     * Выбор цели. byHealth - сначала самые слабые (здоровье + поглощение), иначе самые близкие.
     * fov - угол обзора в градусах (360 = любая цель вокруг).
     */
    public static LivingEntity pick(double range, boolean players, boolean mobs, boolean invisible, boolean byHealth, double fov) {
        return pick(range, players, mobs, invisible, byHealth, fov, false);
    }

    /** Расстояние от глаз до ближайшей точки хитбокса - так сервер проверяет дальность удара (а не до центра). */
    public static double reachDist(Entity e) {
        Vec3d eye = MinecraftClient.getInstance().player.getEyePos();
        Box b = e.getBoundingBox();
        return eye.distanceTo(new Vec3d(
                MathHelper.clamp(eye.x, b.minX, b.maxX),
                MathHelper.clamp(eye.y, b.minY, b.maxY),
                MathHelper.clamp(eye.z, b.minZ, b.maxZ)));
    }

    /** fromEye - считать дальность до хитбокса (для ближнего боя), иначе до центра сущности. */
    public static LivingEntity pick(double range, boolean players, boolean mobs, boolean invisible, boolean byHealth, double fov, boolean fromEye) {
        MinecraftClient mc = MinecraftClient.getInstance();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        double r2 = range * range;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !valid(le, players, mobs, invisible)) {
                continue;
            }
            double d = fromEye ? square(reachDist(le)) : mc.player.squaredDistanceTo(le);
            if (d > r2) {
                continue;
            }
            if (fov < 360 && angleTo(le) > fov / 2.0) {
                continue;
            }
            double score = byHealth ? le.getHealth() + le.getAbsorptionAmount() + d * 0.001 : d;
            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        return best;
    }

    private static double square(double v) {
        return v * v;
    }

    /** Угол по горизонтали между взглядом игрока и направлением на сущность. */
    public static double angleTo(Entity e) {
        MinecraftClient mc = MinecraftClient.getInstance();
        double dx = e.getX() - mc.player.getX();
        double dz = e.getZ() - mc.player.getZ();
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        return Math.abs(MathHelper.wrapDegrees(yaw - mc.player.getYaw()));
    }
}
