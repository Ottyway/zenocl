package dev.zenocl.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Rotations {
    private Rotations() {
    }

    public static float[] to(Vec3d from, Vec3d target) {
        double dx = target.x - from.x;
        double dy = target.y - from.y;
        double dz = target.z - from.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        return new float[]{yaw, MathHelper.clamp(pitch, -90f, 90f)};
    }

    /** Поворачивает игрока к точке не быстрее maxStep градусов за тик. */
    public static void face(ClientPlayerEntity p, Vec3d target, float maxStep) {
        float[] r = to(p.getEyePos(), target);
        float dyaw = MathHelper.wrapDegrees(r[0] - p.getYaw());
        float dpitch = r[1] - p.getPitch();
        dyaw = MathHelper.clamp(dyaw, -maxStep, maxStep);
        dpitch = MathHelper.clamp(dpitch, -maxStep, maxStep);
        p.setYaw(p.getYaw() + dyaw);
        p.setPitch(MathHelper.clamp(p.getPitch() + dpitch, -90f, 90f));
    }
}
