package dev.zenocl.core;

public enum Category {
    COMBAT("Combat"),
    MOVEMENT("Movement"),
    VISUAL("Visual"),
    PLAYER("Player"),
    MISC("Misc");

    public final String title;

    Category(String title) {
        this.title = title;
    }
}
