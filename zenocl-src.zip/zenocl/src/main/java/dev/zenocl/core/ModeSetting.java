package dev.zenocl.core;

public class ModeSetting extends Setting<String> {
    public final String[] modes;

    public ModeSetting(String name, String def, String... modes) {
        super(name, def);
        this.modes = modes;
    }

    public boolean is(String mode) {
        return value.equalsIgnoreCase(mode);
    }

    public void cycle() {
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(value)) {
                value = modes[(i + 1) % modes.length];
                return;
            }
        }
        value = modes[0];
    }

    @Override
    public String serialize() {
        return value;
    }

    @Override
    public void deserialize(String s) {
        for (String m : modes) {
            if (m.equalsIgnoreCase(s)) {
                value = m;
                return;
            }
        }
    }
}
