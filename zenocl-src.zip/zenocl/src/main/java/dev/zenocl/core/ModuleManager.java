package dev.zenocl.core;

import dev.zenocl.hud.HudModule;
import dev.zenocl.modules.combat.AimAssist;
import dev.zenocl.modules.combat.AutoCrystal;
import dev.zenocl.modules.combat.AutoGapple;
import dev.zenocl.modules.combat.AutoTotem;
import dev.zenocl.modules.combat.KillAura;
import dev.zenocl.modules.combat.TriggerBot;
import dev.zenocl.modules.combat.Velocity;
import dev.zenocl.modules.misc.AntiAFK;
import dev.zenocl.modules.misc.ClientSettings;
import dev.zenocl.modules.movement.Fly;
import dev.zenocl.modules.movement.Glide;
import dev.zenocl.modules.movement.Speed;
import dev.zenocl.modules.movement.TargetStrafe;
import dev.zenocl.modules.movement.Sprint;
import dev.zenocl.modules.player.AutoArmor;
import dev.zenocl.modules.player.AutoRespawn;
import dev.zenocl.modules.player.FastPlace;
import dev.zenocl.modules.visual.ArmorHud;
import dev.zenocl.modules.visual.ESP;
import dev.zenocl.modules.visual.Fullbright;
import dev.zenocl.modules.visual.InfoHud;
import dev.zenocl.modules.visual.InventoryHud;
import dev.zenocl.modules.visual.ModuleList;
import dev.zenocl.modules.visual.NotificationsHud;
import dev.zenocl.modules.visual.PotionsHud;
import dev.zenocl.modules.visual.TargetInfo;
import dev.zenocl.modules.visual.Watermark;
import dev.zenocl.modules.combat.AntiBot;
import dev.zenocl.modules.combat.AutoLog;
import dev.zenocl.modules.combat.Surround;
import dev.zenocl.modules.movement.AirJump;
import dev.zenocl.modules.movement.AntiVoid;
import dev.zenocl.modules.movement.AutoWalk;
import dev.zenocl.modules.movement.Bhop;
import dev.zenocl.modules.movement.FastFall;
import dev.zenocl.modules.movement.HighJump;
import dev.zenocl.modules.movement.Jesus;
import dev.zenocl.modules.movement.Spider;
import dev.zenocl.modules.movement.Step;
import dev.zenocl.modules.movement.Strafe;
import dev.zenocl.modules.player.AutoEat;
import dev.zenocl.modules.player.AutoMine;
import dev.zenocl.modules.player.AutoSneak;
import dev.zenocl.modules.player.ChestStealer;
import dev.zenocl.modules.player.MiddleClickFriend;
import dev.zenocl.modules.misc.Panic;
import dev.zenocl.modules.misc.Spammer;
import dev.zenocl.modules.visual.CpsHud;
import dev.zenocl.modules.visual.Keystrokes;
import dev.zenocl.modules.visual.Radar;
import dev.zenocl.modules.visual.SessionHud;
import dev.zenocl.modules.combat.AutoPot;
import dev.zenocl.modules.combat.AutoXP;
import dev.zenocl.modules.combat.BowAim;
import dev.zenocl.modules.combat.PearlThrow;
import dev.zenocl.modules.movement.NoFall;
import dev.zenocl.modules.visual.Zoom;
import dev.zenocl.util.Friends;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("zenocl.properties");

    private ModuleManager() {
    }

    public static void init() {
        // Combat
        MODULES.add(new KillAura());
        MODULES.add(new TriggerBot());
        MODULES.add(new AimAssist());
        MODULES.add(new AutoCrystal());
        MODULES.add(new AutoTotem());
        MODULES.add(new AutoGapple());
        MODULES.add(new Velocity());
        MODULES.add(new AntiBot());
        MODULES.add(new Surround());
        MODULES.add(new AutoLog());
        MODULES.add(new AutoPot());
        MODULES.add(new AutoXP());
        MODULES.add(new BowAim());
        MODULES.add(new PearlThrow());
        // Movement
        MODULES.add(new Sprint());
        MODULES.add(new Speed());
        MODULES.add(new Fly());
        MODULES.add(new Glide());
        MODULES.add(new TargetStrafe());
        MODULES.add(new Jesus());
        MODULES.add(new Spider());
        MODULES.add(new HighJump());
        MODULES.add(new Bhop());
        MODULES.add(new Step());
        MODULES.add(new Strafe());
        MODULES.add(new AirJump());
        MODULES.add(new FastFall());
        MODULES.add(new AntiVoid());
        MODULES.add(new AutoWalk());
        MODULES.add(new NoFall());
        // Visual
        MODULES.add(new ESP());
        MODULES.add(new Fullbright());
        MODULES.add(new Watermark());
        MODULES.add(new ModuleList());
        MODULES.add(new NotificationsHud());
        MODULES.add(new TargetInfo());
        MODULES.add(new InventoryHud());
        MODULES.add(new ArmorHud());
        MODULES.add(new InfoHud());
        MODULES.add(new PotionsHud());
        MODULES.add(new Keystrokes());
        MODULES.add(new CpsHud());
        MODULES.add(new Radar());
        MODULES.add(new SessionHud());
        MODULES.add(new Zoom());
        // Player
        MODULES.add(new FastPlace());
        MODULES.add(new AutoRespawn());
        MODULES.add(new AutoArmor());
        MODULES.add(new ChestStealer());
        MODULES.add(new MiddleClickFriend());
        MODULES.add(new AutoEat());
        MODULES.add(new AutoSneak());
        MODULES.add(new AutoMine());
        // Misc
        MODULES.add(new AntiAFK());
        MODULES.add(new Spammer());
        MODULES.add(new Panic());
        MODULES.add(new ClientSettings());

        boolean first = !Files.exists(CONFIG);
        load();

        // Первый запуск: HUD включён сразу
        if (first) {
            for (Module m : MODULES) {
                if (m instanceof HudModule) {
                    m.loadEnabled(true);
                }
            }
            get(InventoryHud.class).loadEnabled(false);
            get(PotionsHud.class).loadEnabled(false);
        }
    }

    public static List<Module> all() {
        return MODULES;
    }

    public static List<Module> byCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.category == c) {
                out.add(m);
            }
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> cls) {
        for (Module m : MODULES) {
            if (m.getClass() == cls) {
                return (T) m;
            }
        }
        throw new IllegalStateException("Module not registered: " + cls);
    }

    public static boolean isOn(Class<? extends Module> cls) {
        for (Module m : MODULES) {
            if (m.getClass() == cls) {
                return m.isEnabled();
            }
        }
        return false;
    }

    /** Вызывается каждый клиентский тик. */
    public static void tick(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();

        for (Module m : MODULES) {
            int key = m.getKey();
            if (key != 0) {
                boolean down = GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
                if (down && !m.keyWasDown && mc.currentScreen == null) {
                    m.toggle();
                }
                m.keyWasDown = down;
            }
        }

        if (mc.player == null || mc.world == null) {
            return;
        }

        for (Module m : MODULES) {
            if (m.isEnabled()) {
                m.onTick();
            }
        }
    }

    public static void load() {
        load(CONFIG);
    }

    public static void save() {
        save(CONFIG);
    }

    /** Именованный профиль конфига рядом с основным файлом. */
    public static Path profile(String name) {
        return CONFIG.resolveSibling("zenocl-" + name.replaceAll("[^A-Za-z0-9_-]", "") + ".properties");
    }

    public static void load(Path file) {
        if (!Files.exists(file)) {
            return;
        }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            p.load(r);
        } catch (IOException e) {
            return;
        }
        Friends.load(p.getProperty("friends", ""));
        for (Module m : MODULES) {
            String base = m.name + ".";
            if (p.containsKey(base + "enabled")) {
                m.loadEnabled(Boolean.parseBoolean(p.getProperty(base + "enabled")));
            }
            if (p.containsKey(base + "key")) {
                try {
                    m.setKey(Integer.parseInt(p.getProperty(base + "key")));
                } catch (NumberFormatException ignored) {
                }
            }
            for (Setting<?> s : m.settings) {
                String v = p.getProperty(base + s.name);
                if (v != null) {
                    s.deserialize(v);
                }
            }
        }
    }

    public static void save(Path file) {
        Properties p = new Properties();
        for (Module m : MODULES) {
            String base = m.name + ".";
            p.setProperty(base + "enabled", Boolean.toString(m.isEnabled()));
            p.setProperty(base + "key", Integer.toString(m.getKey()));
            for (Setting<?> s : m.settings) {
                p.setProperty(base + s.name, s.serialize());
            }
        }
        p.setProperty("friends", Friends.serialize());
        try {
            Files.createDirectories(file.getParent());
            try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                p.store(w, "ZenoCL config");
            }
        } catch (IOException ignored) {
        }
    }
}
