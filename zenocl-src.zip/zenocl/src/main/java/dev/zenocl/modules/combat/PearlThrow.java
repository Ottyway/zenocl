package dev.zenocl.modules.combat;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.util.Inv;
import dev.zenocl.util.Throw;
import net.minecraft.item.Items;

/** Разовый бросок жемчуга по взгляду: бинд на клавишу, нажал - бросил. */
public class PearlThrow extends Module {
    public PearlThrow() {
        super("PearlThrow", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        int slot = Inv.findHotbar(p, Items.ENDER_PEARL);
        if (slot >= 0 && mc().currentScreen == null) {
            Throw.use(p, slot, null);
        }
        setEnabled(false);
    }
}
