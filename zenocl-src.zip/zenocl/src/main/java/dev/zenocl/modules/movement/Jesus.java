package dev.zenocl.modules.movement;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.util.math.Vec3d;

/** Ходьба по воде: в жидкости игрока постоянно подталкивает вверх. */
public class Jesus extends Module {
    private static final double LIFT = 0.11;
    private final NumSetting speed = add(new NumSetting("Speed", 1.15, 1.0, 1.6, 0.05));
    private final BoolSetting lava = add(new BoolSetting("Lava", false));

    public Jesus() {
        super("Jesus", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        // Shift даёт нырнуть
        if (p.isSneaking()) {
            return;
        }
        if (p.isTouchingWater() || (lava.get() && p.isInLava())) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x * speed.get(), Math.max(v.y, LIFT), v.z * speed.get());
            p.fallDistance = 0f;
        }
    }
}
