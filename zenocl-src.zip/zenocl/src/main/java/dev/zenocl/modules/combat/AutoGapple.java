package dev.zenocl.modules.combat;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Inv;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;

/** Ест золотое яблоко из хотбара, когда здоровье падает ниже порога. */
public class AutoGapple extends Module {
    private final NumSetting health = add(new NumSetting("Health", 10, 2, 19, 1));
    private int prevSlot = -1;
    private boolean eating;

    public AutoGapple() {
        super("AutoGapple", Category.COMBAT);
    }

    private static int findApple(ClientPlayerEntity p) {
        for (Item it : new Item[]{Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE}) {
            int s = Inv.findHotbar(p, it);
            if (s >= 0) {
                return s;
            }
        }
        return -1;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (eating) {
            if (p.getHealth() >= health.getFloat() + 4 || !p.isUsingItem() && findApple(p) < 0) {
                stop();
            } else {
                mc().options.useKey.setPressed(true);
            }
            return;
        }
        if (p.getHealth() > health.getFloat() || mc().currentScreen != null) {
            return;
        }
        int slot = findApple(p);
        if (slot >= 0) {
            prevSlot = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(slot);
            eating = true;
        }
    }

    private void stop() {
        mc().options.useKey.setPressed(false);
        if (prevSlot >= 0) {
            mc().player.getInventory().setSelectedSlot(prevSlot);
        }
        prevSlot = -1;
        eating = false;
    }

    @Override
    public void onDisable() {
        if (eating && mc().player != null) {
            stop();
        }
    }
}
