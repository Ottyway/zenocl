package dev.zenocl.modules.combat;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;

/** Отмена отдачи: логика в ClientPlayNetworkHandlerMixin. */
public class Velocity extends Module {
    public Velocity() {
        super("Velocity", Category.COMBAT);
    }
}
