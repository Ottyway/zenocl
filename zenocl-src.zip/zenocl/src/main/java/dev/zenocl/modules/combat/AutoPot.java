package dev.zenocl.modules.combat;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Throw;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Бросает взрывное зелье исцеления себе под ноги, когда здоровье падает ниже порога. */
public class AutoPot extends Module {
    private static final float DOWN = 90f;
    private final NumSetting health = add(new NumSetting("Health", 10, 1, 19, 1));
    private final NumSetting delay = add(new NumSetting("Delay", 10, 2, 40, 1));
    private int timer;

    public AutoPot() {
        super("AutoPot", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (timer > 0) {
            timer--;
            return;
        }
        if (mc().currentScreen != null || p.getHealth() > health.getFloat()) {
            return;
        }
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            // зелье лечения определяем по названию: работает для английского и русского клиента
            String n = s.getName().getString().toLowerCase();
            if (s.isOf(Items.SPLASH_POTION) && (n.contains("heal") || n.contains("исцел"))) {
                Throw.use(p, i, DOWN);
                timer = delay.getInt();
                return;
            }
        }
    }
}
