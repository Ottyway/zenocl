package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Inv;
import dev.zenocl.util.Rotations;
import dev.zenocl.util.Targets;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * CrystalAura: выбирает позицию и кристалл по реальному урону взрыва (формула ваниллы:
 * расстояние, броня, сложность, укрытия), бьёт новый кристалл мгновенно при появлении,
 * ставит каждый тик без задержки, меняет слот тихо. Камера не дёргается (Rotate выключен по умолчанию).
 */
public class AutoCrystal extends Module {
    private record Eval(boolean ok, float target, float self) {
    }

    private record Cand(BlockPos pos, float ub) {
    }

    private static final float POWER2 = 12f;           // мощность кристалла 6 * 2
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private final NumSetting targetRange = add(new NumSetting("TargetRange", 10, 4, 14, 1));
    private final NumSetting placeRange = add(new NumSetting("PlaceRange", 4.8, 2, 6, 0.1));
    private final NumSetting breakRange = add(new NumSetting("BreakRange", 4.8, 2, 6, 0.1));
    private final NumSetting wallRange = add(new NumSetting("WallRange", 3.0, 0, 6, 0.5));
    private final NumSetting placeDelay = add(new NumSetting("PlaceDelay", 0, 0, 10, 1));
    private final NumSetting breakDelay = add(new NumSetting("BreakDelay", 0, 0, 10, 1));
    private final NumSetting minDamage = add(new NumSetting("MinDamage", 5.0, 1, 20, 0.5));
    private final NumSetting maxSelf = add(new NumSetting("MaxSelfDamage", 7.0, 1, 20, 0.5));
    private final NumSetting facePlaceHp = add(new NumSetting("FacePlaceHP", 8, 0, 36, 1));
    private final ModeSetting switchMode = add(new ModeSetting("Switch", "Silent", "None", "Normal", "Silent"));
    private final ModeSetting enemyArmor = add(new ModeSetting("EnemyArmor", "ProtIV", "None", "ProtIV", "BlastIV"));
    private final ModeSetting priority = add(new ModeSetting("Priority", "Distance", "Distance", "Health"));
    private final BoolSetting place = add(new BoolSetting("Place", true));
    private final BoolSetting breakC = add(new BoolSetting("Break", true));
    private final BoolSetting instantBreak = add(new BoolSetting("InstantBreak", true));
    private final BoolSetting antiWeakness = add(new BoolSetting("AntiWeakness", true));
    private final BoolSetting noSuicide = add(new BoolSetting("NoSuicide", true));
    private final BoolSetting pauseOnUse = add(new BoolSetting("PauseOnUse", true));
    private final BoolSetting rotate = add(new BoolSetting("Rotate", false));

    private final Map<Integer, Integer> hits = new HashMap<>();
    private final Map<BlockPos, Integer> placed = new HashMap<>();
    private LivingEntity target;
    private int age;
    private int lastBreak = -100;
    private int lastPlace = -100;

    public AutoCrystal() {
        super("AutoCrystal", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        hits.clear();
        placed.clear();
        target = null;
    }

    // ------------------------------------------------------------------ тик

    @Override
    public void onTick() {
        age++;
        ClientPlayerEntity p = mc().player;
        if (age % 40 == 0) {
            hits.values().removeIf(t -> age - t > 40);
            placed.values().removeIf(t -> age - t > 40);
        }
        if (mc().currentScreen != null || (pauseOnUse.get() && p.isUsingItem())) {
            return;
        }
        target = Targets.pick(targetRange.get(), true, false, true, priority.is("Health"), 360);
        if (target == null) {
            return;
        }
        Targets.mark(target);

        if (breakC.get() && age - lastBreak >= breakDelay.getInt()) {
            doBreak(p);
        }
        if (place.get() && age - lastPlace >= placeDelay.getInt()) {
            doPlace(p);
        }
    }

    /** Вызывается сразу при появлении кристалла у клиента: бьём в тот же тик, без ожидания. */
    public void onSpawn(EndCrystalEntity c) {
        if (!isEnabled() || !breakC.get() || !instantBreak.get()) {
            return;
        }
        ClientPlayerEntity p = mc().player;
        LivingEntity t = target;
        if (p == null || mc().world == null || mc().currentScreen != null || t == null || !t.isAlive()) {
            return;
        }
        if ((pauseOnUse.get() && p.isUsingItem()) || age - lastBreak < breakDelay.getInt() || hitRecently(c.getId())) {
            return;
        }
        if (p.distanceTo(c) > breakRange.get()) {
            return;
        }
        if (evaluate(c.getEntityPos(), t, p, effectiveMin(t)).ok()) {
            attack(p, c);
        }
    }

    // ------------------------------------------------------------------ удар

    private void doBreak(ClientPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        EndCrystalEntity best = null;
        float bestScore = -1e9f;
        float min = effectiveMin(target);
        for (Entity e : mc().world.getEntities()) {
            if (!(e instanceof EndCrystalEntity c) || c.isRemoved() || hitRecently(c.getId())) {
                continue;
            }
            double dist = p.distanceTo(c);
            if (dist > breakRange.get()) {
                continue;
            }
            if (dist > wallRange.get() && !visible(eye, c.getEntityPos())) {
                continue;
            }
            Eval ev = evaluate(c.getEntityPos(), target, p, min);
            if (!ev.ok()) {
                continue;
            }
            float score = ev.target() - ev.self() * 0.9f;
            if (score > bestScore) {
                bestScore = score;
                best = c;
            }
        }
        if (best != null) {
            attack(p, best);
        }
    }

    private void attack(ClientPlayerEntity p, EndCrystalEntity c) {
        int prev = -1;
        if (antiWeakness.get() && p.hasStatusEffect(StatusEffects.WEAKNESS) && !Inv.isWeapon(p.getMainHandStack())) {
            int s = Inv.findBestHotbar(p, "_sword");
            if (s >= 0) {
                prev = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(s);
            }
        }
        if (rotate.get()) {
            Rotations.face(p, c.getEntityPos().add(0, 0.5, 0), 180f);
        }
        mc().interactionManager.attackEntity(p, c);
        p.swingHand(Hand.MAIN_HAND);
        if (prev >= 0) {
            p.getInventory().setSelectedSlot(prev);
        }
        hits.put(c.getId(), age);
        lastBreak = age;
    }

    private boolean hitRecently(int id) {
        Integer t = hits.get(id);
        return t != null && age - t < 3;
    }

    // ------------------------------------------------------------------ установка

    private void doPlace(ClientPlayerEntity p) {
        Hand hand = null;
        int swapSlot = -1;
        if (p.getOffHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.OFF_HAND;
        } else if (p.getMainHandStack().isOf(Items.END_CRYSTAL)) {
            hand = Hand.MAIN_HAND;
        } else if (!switchMode.is("None")) {
            swapSlot = Inv.findHotbar(p, Items.END_CRYSTAL);
            if (swapSlot >= 0) {
                hand = Hand.MAIN_HAND;
            }
        }
        if (hand == null) {
            return;
        }

        ClientWorld world = mc().world;
        Vec3d eye = p.getEyePos();
        Vec3d tp = target.getEntityPos();
        float min = effectiveMin(target);
        double range = placeRange.get();
        int ri = (int) Math.ceil(range);
        BlockPos origin = p.getBlockPos();

        // 1) дешёвый отбор: блок-основание, воздух сверху, дальность, верхняя оценка урона (экспозиция = 1)
        List<Cand> cands = new ArrayList<>();
        for (int x = -ri; x <= ri; x++) {
            for (int y = -ri; y <= ri; y++) {
                for (int z = -ri; z <= ri; z++) {
                    BlockPos pos = origin.add(x, y, z);
                    var st = world.getBlockState(pos);
                    if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) {
                        continue;
                    }
                    if (!world.getBlockState(pos.up()).isAir()) {
                        continue;
                    }
                    Vec3d c = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
                    if (eye.distanceTo(c) > range || c.distanceTo(tp) > 11.0) {
                        continue;
                    }
                    Integer last = placed.get(pos);
                    if (last != null && age - last < 4) {
                        continue;
                    }
                    float ub = damage(c, target, 1f);
                    if (ub >= min) {
                        cands.add(new Cand(pos, ub));
                    }
                }
            }
        }
        if (cands.isEmpty()) {
            return;
        }
        cands.sort((a, b) -> Float.compare(b.ub(), a.ub()));

        // 2) точный расчёт только для лучших кандидатов
        BlockPos best = null;
        float bestScore = -1e9f;
        int evaluated = 0;
        for (Cand cd : cands) {
            if (evaluated >= 8) {
                break;
            }
            BlockPos pos = cd.pos();
            Vec3d c = new Vec3d(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
            Box box = new Box(pos.getX(), pos.getY() + 1.0, pos.getZ(), pos.getX() + 1.0, pos.getY() + 3.0, pos.getZ() + 1.0);
            if (!world.getOtherEntities(null, box).isEmpty()) {
                continue;
            }
            if (eye.distanceTo(c) > wallRange.get() && !visibleBlock(eye, c, pos)) {
                continue;
            }
            evaluated++;
            Eval ev = evaluate(c, target, p, min);
            if (!ev.ok()) {
                continue;
            }
            float score = ev.target() - ev.self() * 0.9f;
            if (score > bestScore) {
                bestScore = score;
                best = pos;
            }
        }
        if (best == null) {
            return;
        }

        Vec3d hit = new Vec3d(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5);
        int prev = -1;
        if (swapSlot >= 0) {
            prev = p.getInventory().getSelectedSlot();
            p.getInventory().setSelectedSlot(swapSlot);
        }
        if (rotate.get()) {
            Rotations.face(p, hit, 180f);
        }
        mc().interactionManager.interactBlock(p, hand, new BlockHitResult(hit, Direction.UP, best, false));
        p.swingHand(hand);
        if (prev >= 0 && switchMode.is("Silent")) {
            p.getInventory().setSelectedSlot(prev);
        }
        placed.put(best, age);
        lastPlace = age;
    }

    // ------------------------------------------------------------------ оценка урона

    private float effectiveMin(LivingEntity t) {
        boolean face = facePlaceHp.get() > 0 && t.getHealth() + t.getAbsorptionAmount() <= facePlaceHp.get();
        return face ? 1f : minDamage.getFloat();
    }

    private Eval evaluate(Vec3d c, LivingEntity t, ClientPlayerEntity p, float min) {
        float td = damage(c, t, -1f);
        if (td < min) {
            return new Eval(false, td, 0f);
        }
        float sd = damage(c, p, -1f);
        float myHp = p.getHealth() + p.getAbsorptionAmount();
        boolean kill = td >= t.getHealth() + t.getAbsorptionAmount();
        boolean ok = (kill || sd <= maxSelf.getFloat()) && (!noSuicide.get() || sd < myHp - 1f);
        return new Eval(ok, td, sd);
    }

    /** Урон от взрыва кристалла в точке center. exposureOverride < 0 - считать укрытия лучами. */
    private float damage(Vec3d center, LivingEntity e, float exposureOverride) {
        double dist = Math.sqrt(e.squaredDistanceTo(center)) / POWER2;
        if (dist > 1.0) {
            return 0f;
        }
        float exposure = exposureOverride >= 0 ? exposureOverride : exposure(center, e);
        double impact = (1.0 - dist) * exposure;
        float dmg = (int) ((impact * impact + impact) / 2.0 * 7.0 * POWER2 + 1.0);

        if (e instanceof PlayerEntity) {
            switch (mc().world.getDifficulty()) {
                case PEACEFUL -> dmg = 0f;
                case EASY -> dmg = Math.min(dmg / 2f + 1f, dmg);
                case HARD -> dmg = dmg * 1.5f;
                default -> {
                }
            }
        }

        float armor = e.getArmor();
        if (armor > 0) {
            float tough = toughness(e);
            float f = 2f + tough / 4f;
            float g = MathHelper.clamp(armor - dmg / f, armor * 0.2f, 20f);
            dmg *= 1f - g / 25f;
            // чары врага оцениваем по настройке; на себя считаем без чар (запас по безопасности)
            if (e != mc().player) {
                if (enemyArmor.is("ProtIV")) {
                    dmg *= 1f - 16f * 0.04f;
                } else if (enemyArmor.is("BlastIV")) {
                    dmg *= 1f - 20f * 0.04f;
                }
            }
        }
        StatusEffectInstance res = e.getStatusEffect(StatusEffects.RESISTANCE);
        if (res != null) {
            dmg *= Math.max(0f, 1f - (res.getAmplifier() + 1) * 0.2f);
        }
        return Math.max(0f, dmg);
    }

    private static float toughness(LivingEntity e) {
        float t = 0;
        for (EquipmentSlot s : ARMOR) {
            String path = Inv.path(e.getEquippedStack(s));
            if (path.startsWith("netherite_")) {
                t += 3;
            } else if (path.startsWith("diamond_")) {
                t += 2;
            }
        }
        return t;
    }

    /** Доля тела, не закрытая блоками от точки взрыва (7 лучей вместо полной сетки ваниллы). */
    private float exposure(Vec3d center, LivingEntity e) {
        Box b = e.getBoundingBox();
        double cx = (b.minX + b.maxX) / 2, cz = (b.minZ + b.maxZ) / 2;
        double h = b.maxY - b.minY;
        double wx = (b.maxX - b.minX) * 0.3, wz = (b.maxZ - b.minZ) * 0.3;
        double mid = b.minY + h * 0.5;
        Vec3d[] pts = {
                new Vec3d(cx, b.minY + h * 0.1, cz), new Vec3d(cx, mid, cz), new Vec3d(cx, b.minY + h * 0.9, cz),
                new Vec3d(cx - wx, mid, cz - wz), new Vec3d(cx + wx, mid, cz - wz),
                new Vec3d(cx - wx, mid, cz + wz), new Vec3d(cx + wx, mid, cz + wz)
        };
        int seen = 0;
        for (Vec3d pt : pts) {
            BlockHitResult r = mc().world.raycast(new RaycastContext(pt, center, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, e));
            if (r.getType() == HitResult.Type.MISS) {
                seen++;
            }
        }
        return seen / (float) pts.length;
    }

    private boolean visible(Vec3d from, Vec3d to) {
        BlockHitResult r = mc().world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc().player));
        return r.getType() == HitResult.Type.MISS;
    }

    private boolean visibleBlock(Vec3d from, Vec3d to, BlockPos base) {
        BlockHitResult r = mc().world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc().player));
        return r.getType() == HitResult.Type.MISS || r.getBlockPos().equals(base);
    }
}
