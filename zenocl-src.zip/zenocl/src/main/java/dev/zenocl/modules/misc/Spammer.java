package dev.zenocl.modules.misc;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

import java.util.Random;

public class Spammer extends Module {
    private static final int TICKS_PER_SECOND = 20;
    private final ModeSetting text = add(new ModeSetting("Text", "ZenoCL", "ZenoCL", "ez", "gg", "ZenoCL on top"));
    private final NumSetting delay = add(new NumSetting("Delay", 8, 2, 60, 1));
    // суффикс обходит антиспам-фильтры, которые режут одинаковые сообщения
    private final BoolSetting random = add(new BoolSetting("RandomSuffix", true));
    private final Random rng = new Random();
    private int timer;

    public Spammer() {
        super("Spammer", Category.MISC);
    }

    @Override
    public void onTick() {
        if (++timer < delay.getInt() * TICKS_PER_SECOND) {
            return;
        }
        timer = 0;
        String msg = text.get() + (random.get() ? " " + (1000 + rng.nextInt(9000)) : "");
        mc().player.networkHandler.sendChatMessage(msg);
    }

    @Override
    public void onEnable() {
        timer = 0;
    }
}
