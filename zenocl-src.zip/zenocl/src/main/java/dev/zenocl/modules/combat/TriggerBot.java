package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.NumSetting;
import dev.zenocl.core.Module;
import dev.zenocl.util.Crits;
import dev.zenocl.util.Inv;
import dev.zenocl.util.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;

public class TriggerBot extends Module {
    private final BoolSetting onlyCrits = add(new BoolSetting("OnlyCrits", false));
    private final BoolSetting onlyWeapon = add(new BoolSetting("OnlyWeapon", false));
    private final NumSetting cooldown = add(new NumSetting("Cooldown", 0.93, 0.5, 1.0, 0.01));
    private final NumSetting hitChance = add(new NumSetting("HitChance", 100, 10, 100, 5));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));

    public TriggerBot() {
        super("TriggerBot", Category.COMBAT);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        Entity e = mc().targetedEntity;
        if (mc().currentScreen != null || !(e instanceof LivingEntity le)) {
            return;
        }
        if (!Targets.valid(le, players.get(), mobs.get(), true)) {
            return;
        }
        if (onlyWeapon.get() && !Inv.isWeapon(p.getMainHandStack())) {
            return;
        }
        if (p.getAttackCooldownProgress(0.5f) < cooldown.getFloat() || Math.random() * 100.0 >= hitChance.get()) {
            return;
        }
        if (onlyCrits.get()) {
            if (!Crits.canCrit(p)) {
                return;
            }
            Crits.unsprint(p);
        }
        Targets.mark(le);
        mc().interactionManager.attackEntity(p, le);
        p.swingHand(Hand.MAIN_HAND);
    }
}
