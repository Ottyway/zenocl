package dev.zenocl.modules.movement;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.ModuleManager;
import dev.zenocl.core.NumSetting;
import dev.zenocl.modules.combat.KillAura;
import dev.zenocl.util.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

/** Бег по кругу вокруг цели. Радиус, скорость, направление и условия включения настраиваются. */
public class TargetStrafe extends Module {
    private final NumSetting range = add(new NumSetting("Range", 6.0, 2.0, 12.0, 0.5));
    private final NumSetting radius = add(new NumSetting("Radius", 2.5, 1.0, 6.0, 0.1));
    private final NumSetting speed = add(new NumSetting("Speed", 0.30, 0.10, 1.0, 0.01));
    private final ModeSetting direction = add(new ModeSetting("Direction", "Auto", "Clockwise", "Counter", "Auto"));
    private final BoolSetting autoJump = add(new BoolSetting("AutoJump", true));
    private final BoolSetting requireAura = add(new BoolSetting("RequireAura", false));
    private final BoolSetting onlyMoving = add(new BoolSetting("OnlyWhenMoving", false));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));

    private int sign = 1;
    private int flipCooldown;

    public TargetStrafe() {
        super("TargetStrafe", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        sign = direction.is("Counter") ? -1 : 1;
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (mc().currentScreen != null || (requireAura.get() && !ModuleManager.isOn(KillAura.class))) {
            return;
        }
        if (onlyMoving.get() && !Move.moving()) {
            return;
        }
        LivingEntity t = Targets.nearest(range.get(), players.get(), mobs.get(), true);
        if (t == null) {
            return;
        }

        if (direction.is("Clockwise")) {
            sign = 1;
        } else if (direction.is("Counter")) {
            sign = -1;
        } else if (p.horizontalCollision && flipCooldown <= 0) {
            sign = -sign;
            flipCooldown = 10;
        }
        if (flipCooldown > 0) {
            flipCooldown--;
        }

        double dx = p.getX() - t.getX();
        double dz = p.getZ() - t.getZ();
        double r = radius.get();
        double angle = Math.atan2(dz, dx) + sign * (speed.get() / r);
        double wantX = t.getX() + Math.cos(angle) * r;
        double wantZ = t.getZ() + Math.sin(angle) * r;

        double mx = wantX - p.getX();
        double mz = wantZ - p.getZ();
        double len = Math.sqrt(mx * mx + mz * mz);
        if (len > speed.get()) {
            mx = mx / len * speed.get();
            mz = mz / len * speed.get();
        }
        if (autoJump.get() && p.isOnGround()) {
            p.jump();
        }
        Vec3d v = p.getVelocity();
        p.setVelocity(mx, v.y, mz);
    }
}
