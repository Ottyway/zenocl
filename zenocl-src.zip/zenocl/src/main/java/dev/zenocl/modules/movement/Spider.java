package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.util.math.Vec3d;

public class Spider extends Module {
    private final NumSetting speed = add(new NumSetting("Speed", 0.25, 0.1, 0.6, 0.01));

    public Spider() {
        super("Spider", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (p.horizontalCollision && !p.isSneaking()) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, speed.get(), v.z);
            p.fallDistance = 0f;
        }
    }
}
