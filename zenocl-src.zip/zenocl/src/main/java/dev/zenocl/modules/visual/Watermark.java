package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Icon3D;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public class Watermark extends HudModule {
    private final BoolSetting name = add(new BoolSetting("Nickname", true));
    private final BoolSetting fps = add(new BoolSetting("FPS", true));
    private final BoolSetting ping = add(new BoolSetting("Ping", true));
    private final BoolSetting icon = add(new BoolSetting("Icon3D", true));

    public Watermark() {
        super("Watermark");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        MinecraftClient mc = MinecraftClient.getInstance();
        StringBuilder info = new StringBuilder();
        if (name.get()) {
            info.append(mc.getSession().getUsername());
        }
        if (fps.get()) {
            info.append(info.length() > 0 ? "   " : "").append(mc.getCurrentFps()).append(" fps");
        }
        if (ping.get() && mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            info.append(info.length() > 0 ? "   " : "").append(e != null ? e.getLatency() : 0).append(" ms");
        }
        String s = info.toString();
        int iconBox = icon.get() ? 24 : 0;
        int logoW = iconBox + Render.width("ZenoCL") + 12;
        int w = logoW + (s.isEmpty() ? 0 : Render.width(s) + 12);
        int x = 6, y = 6, h = 24;

        Render.rrect(ctx, x, y, w, h, Render.bg());
        Render.rrect(ctx, x, y, logoW, h, Render.withAlpha(Render.accent(0), 0.20f));
        ctx.fillGradient(x + 2, y + h - 2, x + logoW - 2, y + h - 1, Render.accent(0), Render.accent(2));
        if (icon.get()) {
            Icon3D.draw(ctx, x + 14, y + h / 2, 14f, 0);
        }
        Render.text(ctx, "ZenoCL", x + iconBox + 4, y + 8, Render.accent(0.3));
        if (!s.isEmpty()) {
            Render.text(ctx, s, x + logoW + 6, y + 8, Render.TEXT);
        }
    }
}
