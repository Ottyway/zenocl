package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Crits;
import dev.zenocl.util.Inv;
import dev.zenocl.util.Rotations;
import dev.zenocl.util.SilentRot;
import dev.zenocl.util.Targets;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class KillAura extends Module {
    private final NumSetting range = add(new NumSetting("Range", 3.0, 1.0, 6.0, 0.1));
    private final NumSetting fov = add(new NumSetting("FOV", 360, 30, 360, 10));
    private final NumSetting turn = add(new NumSetting("TurnSpeed", 90, 10, 180, 5));
    private final ModeSetting priority = add(new ModeSetting("Priority", "Distance", "Distance", "Health"));
    private final ModeSetting crits = add(new ModeSetting("Crits", "Off", "Off", "Falling", "Jump"));
    private final ModeSetting rotation = add(new ModeSetting("Rotation", "Client", "Client", "Silent", "None"));
    private final ModeSetting aimPoint = add(new ModeSetting("AimPoint", "Chest", "Head", "Chest", "Legs"));
    private final NumSetting jitter = add(new NumSetting("Jitter", 0.0, 0.0, 0.3, 0.02));
    private final NumSetting hitChance = add(new NumSetting("HitChance", 100, 10, 100, 5));
    private final BoolSetting throughWalls = add(new BoolSetting("ThroughWalls", true));
    private final BoolSetting cooldown = add(new BoolSetting("Cooldown", true));
    private final BoolSetting sprintReset = add(new BoolSetting("SprintReset", true));
    private final BoolSetting autoWeapon = add(new BoolSetting("AutoWeapon", true));
    private final BoolSetting shieldBreak = add(new BoolSetting("ShieldBreak", true));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    private final BoolSetting invisible = add(new BoolSetting("Invisible", true));

    private final NumSetting smooth = add(new NumSetting("Smoothness", 14, 4, 40, 1));
    private final BoolSetting rayCheck = add(new BoolSetting("RayCheck", true));
    private final BoolSetting targetLock = add(new BoolSetting("TargetLock", true));
    private LivingEntity lock;
    // режим Client: тик лишь выбирает точку, а камера плавно доворачивается каждый кадр (frame)
    private Vec3d aimTarget;
    private long aimStamp;
    private long lastFrame = System.nanoTime();

    public KillAura() {
        super("KillAura", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        lock = null;
        aimTarget = null;
    }

    /** Вызывается каждый кадр из HUD-колбэка: поворот камеры не зависит от 20 тиков в секунду. */
    public void frame() {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrame) / 1.0e9f);
        lastFrame = now;
        ClientPlayerEntity p = mc().player;
        // точка устаревает за 150 мс: цель пропала - камера сразу отпускается
        if (!isEnabled() || p == null || aimTarget == null || now - aimStamp > 150_000_000L
                || !rotation.is("Client") || mc().currentScreen != null) {
            return;
        }
        Rotations.faceSmooth(p, aimTarget, turn.getFloat() * 20f, smooth.getFloat(), dt);
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc().player;
        if (mc().currentScreen != null) {
            return;
        }
        // дальность считаем до хитбокса: именно так сервер проверяет досягаемость удара
        LivingEntity t = keepLock(p);
        if (t == null) {
            t = Targets.pick(range.get(), players.get(), mobs.get(), invisible.get(), priority.is("Health"), fov.get(), true);
            lock = t;
        }
        if (t == null) {
            return;
        }
        if (!throughWalls.get() && !p.canSee(t)) {
            return;
        }
        Targets.mark(t);
        Vec3d aim = aimPoint(p, t);
        if (rotation.is("Client")) {
            aimTarget = aim;
            aimStamp = System.nanoTime();
        } else {
            Rotations.aim(p, aim, turn.getFloat(), rotation.get());
        }
        pickWeapon(p, t);

        if (Math.random() * 100.0 >= hitChance.get()) {
            return;
        }
        boolean ready = !cooldown.get() || p.getAttackCooldownProgress(0.5f) >= 0.93f;
        if (!ready) {
            return;
        }
        // Удар уходит сразу, а повёрнутые углы доходят до сервера только со следующим пакетом движения.
        // Поэтому бьём лишь когда последние ОТПРАВЛЕННЫЕ углы уже смотрят в цель - иначе сервер видит удар под старым углом.
        if (rayCheck.get() && !onTarget(p, t)) {
            return;
        }

        // Крит-режимы: Falling ждёт падения, Jump сам прыгает с земли и бьёт в падении
        if (!crits.is("Off")) {
            if (crits.is("Jump") && p.isOnGround() && !p.isSneaking()) {
                p.jump();
                return;
            }
            if (!Crits.canCrit(p)) {
                return;
            }
            Crits.unsprint(p);
        } else if (sprintReset.get()) {
            Crits.unsprint(p);
        }

        mc().interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
    }

    /** Держит текущую цель, пока она жива и в зоне: без метаний между двумя близкими игроками. */
    private LivingEntity keepLock(ClientPlayerEntity p) {
        LivingEntity l = lock;
        if (!targetLock.get() || l == null || l.isRemoved() || !Targets.valid(l, players.get(), mobs.get(), invisible.get())) {
            return null;
        }
        if (Targets.reachDist(l) > range.get() + 0.25) {
            return null;
        }
        if (fov.get() < 360 && Targets.angleTo(l) > fov.get() / 2.0) {
            return null;
        }
        return l;
    }

    /** Точка на хитбоксе, ближайшая к глазам на выбранной высоте: луч в неё всегда попадает в цель. */
    private Vec3d aimPoint(ClientPlayerEntity p, LivingEntity t) {
        double aimY = aimPoint.is("Head") ? 0.9 : aimPoint.is("Legs") ? 0.25 : 0.65;
        Box b = t.getBoundingBox();
        Vec3d eye = p.getEyePos();
        double j = jitter.get();
        // небольшой шум точки прицеливания: движения выглядят живее; запас 0.1 от края, чтобы не промахиваться по краю
        double x = MathHelper.clamp(eye.x + (Math.random() - 0.5) * j * 2, b.minX + 0.1, b.maxX - 0.1);
        double z = MathHelper.clamp(eye.z + (Math.random() - 0.5) * j * 2, b.minZ + 0.1, b.maxZ - 0.1);
        return new Vec3d(x, b.minY + t.getHeight() * aimY, z);
    }

    /** Попадает ли луч из глаз по последним отправленным серверу углам в хитбокс цели в пределах дальности. */
    private boolean onTarget(ClientPlayerEntity p, LivingEntity t) {
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(Vec3d.fromPolar(SilentRot.serverPitch(p), SilentRot.serverYaw(p)).multiply(range.get()));
        return t.getBoundingBox().expand(0.05).raycast(eye, end).isPresent();
    }

    private void pickWeapon(ClientPlayerEntity p, LivingEntity t) {
        int slot = -1;
        if (shieldBreak.get() && t instanceof PlayerEntity pl && pl.isBlocking()) {
            slot = Inv.findBestHotbar(p, "_axe");
        }
        if (slot < 0 && autoWeapon.get() && !Inv.isWeapon(p.getMainHandStack())) {
            slot = Inv.findBestHotbar(p, "_sword");
            if (slot < 0) {
                slot = Inv.findBestHotbar(p, "_axe");
            }
        }
        if (slot >= 0 && slot != p.getInventory().getSelectedSlot()) {
            p.getInventory().setSelectedSlot(slot);
        }
    }
}
