package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

public class PotionsHud extends HudModule {
    public PotionsHud() {
        super("Potions");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        var effects = MinecraftClient.getInstance().player.getStatusEffects();
        if (effects.isEmpty()) {
            return;
        }
        int y = sh / 2 - 40;
        int x = 6;
        for (StatusEffectInstance e : effects) {
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            int secs = e.getDuration() / 20;
            String time = e.isInfinite() ? "inf" : String.format("%d:%02d", secs / 60, secs % 60);
            int w = Render.width(name) + Render.width(time) + 20;
            Render.rrect(ctx, x, y, w, 14, Render.bg());
            ctx.fill(x + 1, y + 2, x + 3, y + 12, Render.accent(y * 0.05));
            Render.text(ctx, name, x + 7, y + 3, Render.TEXT);
            Render.text(ctx, time, x + w - 6 - Render.width(time), y + 3, Render.TEXT_DIM);
            y += 16;
        }
    }
}
