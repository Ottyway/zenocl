package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

/** Автопрыжки с разгоном: на земле прыгает, в воздухе держит заданную скорость. */
public class Bhop extends Module {
    private final NumSetting speed = add(new NumSetting("Speed", 0.32, 0.2, 0.8, 0.01));

    public Bhop() {
        super("Bhop", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (!Move.moving() || p.isSneaking() || p.isTouchingWater()) {
            return;
        }
        if (p.isOnGround()) {
            p.jump();
        }
        double[] d = Move.dir();
        p.setVelocity(d[0] * speed.get(), p.getVelocity().y, d[1] * speed.get());
    }
}
