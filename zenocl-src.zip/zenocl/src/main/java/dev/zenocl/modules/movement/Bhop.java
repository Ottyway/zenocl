package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

/** Автопрыжки с управлением в воздухе. Boost 1.00 - чистая ваниль (только автопрыжок). */
public class Bhop extends Module {
    private final NumSetting boost = add(new NumSetting("Boost", 1.05, 1.0, 1.4, 0.01));

    public Bhop() {
        super("Bhop", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        Move.run(mc().player, boost.get(), true, true);
    }
}
