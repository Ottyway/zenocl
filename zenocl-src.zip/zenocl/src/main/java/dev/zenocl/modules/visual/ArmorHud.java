package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHud extends HudModule {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public ArmorHud() {
        super("ArmorHUD");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = 4 * 18 + 4, h = 22;
        int x = sw / 2 - w / 2 + 0;
        int y = sh - 76;
        Render.rrect(ctx, x, y, w, h, Render.bg());
        for (int i = 0; i < SLOTS.length; i++) {
            ItemStack s = mc.player.getEquippedStack(SLOTS[i]);
            if (!s.isEmpty()) {
                ctx.drawItem(s, x + 2 + i * 18, y + 3);
                ctx.drawStackOverlay(mc.textRenderer, s, x + 2 + i * 18, y + 3);
            }
        }
    }
}
