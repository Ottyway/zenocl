package dev.zenocl.modules.visual;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

public class Fullbright extends Module {
    public Fullbright() {
        super("Fullbright", Category.VISUAL);
    }

    @Override
    public void onTick() {
        mc().player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
    }

    @Override
    public void onDisable() {
        if (mc().player != null) {
            mc().player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }
    }
}
