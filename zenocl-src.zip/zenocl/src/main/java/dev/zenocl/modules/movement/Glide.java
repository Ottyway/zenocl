package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.util.math.Vec3d;

public class Glide extends Module {
    private final NumSetting fall = add(new NumSetting("FallSpeed", 0.08, 0.01, 0.4, 0.01));

    public Glide() {
        super("Glide", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        Vec3d v = p.getVelocity();
        if (!p.isOnGround() && v.y < -fall.get()) {
            p.setVelocity(v.x, -fall.get(), v.z);
        }
    }
}
