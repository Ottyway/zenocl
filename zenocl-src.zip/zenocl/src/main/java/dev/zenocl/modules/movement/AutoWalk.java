package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;

public class AutoWalk extends Module {
    public AutoWalk() {
        super("AutoWalk", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        if (mc().currentScreen == null) {
            mc().options.forwardKey.setPressed(true);
        }
    }

    @Override
    public void onDisable() {
        mc().options.forwardKey.setPressed(false);
    }
}
