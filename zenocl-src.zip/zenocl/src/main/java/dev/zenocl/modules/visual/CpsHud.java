package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** Клики в секунду для левой и правой кнопки мыши. */
public class CpsHud extends HudModule {
    private static final long WINDOW_MS = 1000;
    private final ArrayDeque<Long> left = new ArrayDeque<>();
    private final ArrayDeque<Long> right = new ArrayDeque<>();
    private boolean wasLeft;
    private boolean wasRight;

    public CpsHud() {
        super("CPS");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        long win = MinecraftClient.getInstance().getWindow().getHandle();
        long now = System.currentTimeMillis();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        if (l && !wasLeft) {
            left.add(now);
        }
        if (r && !wasRight) {
            right.add(now);
        }
        wasLeft = l;
        wasRight = r;
        while (!left.isEmpty() && now - left.peekFirst() > WINDOW_MS) {
            left.pollFirst();
        }
        while (!right.isEmpty() && now - right.peekFirst() > WINDOW_MS) {
            right.pollFirst();
        }
        String s = "CPS  " + left.size() + " | " + right.size();
        int w = Render.width(s) + 14;
        int x = 6;
        int y = sh / 2 + 44;
        Render.rrect(ctx, x, y, w, 15, Render.bg());
        ctx.fillGradient(x + 1, y + 2, x + 3, y + 13, Render.accent(0), Render.accent(2));
        Render.text(ctx, s, x + 8, y + 4, Render.TEXT);
    }
}
