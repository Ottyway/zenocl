package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import dev.zenocl.util.Rotations;
import dev.zenocl.util.Targets;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

/** Наводится на цель при натяжении лука/арбалета с упреждением и поправкой на падение стрелы. */
public class BowAim extends Module {
    private static final double ARROW_SPEED = 3.0;   // блоков за тик при полном натяжении
    private static final double ARROW_GRAVITY = 0.05;
    private final NumSetting range = add(new NumSetting("Range", 40, 10, 80, 5));
    private final NumSetting fov = add(new NumSetting("FOV", 120, 20, 360, 10));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));

    public BowAim() {
        super("BowAim", Category.COMBAT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (!p.isUsingItem() || !(p.getActiveItem().isOf(Items.BOW) || p.getActiveItem().isOf(Items.CROSSBOW))) {
            return;
        }
        LivingEntity t = Targets.pick(range.get(), players.get(), mobs.get(), true, false, fov.get());
        if (t == null) {
            return;
        }
        double flight = p.distanceTo(t) / ARROW_SPEED;
        Vec3d lead = t.getVelocity().multiply(flight);
        double drop = 0.5 * ARROW_GRAVITY * flight * flight;
        Rotations.face(p, t.getEyePos().add(lead.x, lead.y + drop, lead.z), 180f);
    }
}
