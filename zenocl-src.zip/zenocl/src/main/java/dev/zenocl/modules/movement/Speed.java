package dev.zenocl.modules.movement;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.util.math.Vec3d;

public class Speed extends Module {
    private final NumSetting speed = add(new NumSetting("Speed", 0.32, 0.1, 1.0, 0.01));
    private final BoolSetting bhop = add(new BoolSetting("Bhop", true));

    public Speed() {
        super("Speed", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (!Move.moving() || p.isSneaking() || p.isTouchingWater() || p.isClimbing()) {
            return;
        }
        if (bhop.get() && p.isOnGround()) {
            p.jump();
        }
        double[] d = Move.dir();
        Vec3d v = p.getVelocity();
        p.setVelocity(d[0] * speed.get(), v.y, d[1] * speed.get());
    }
}
