package dev.zenocl.modules.movement;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

/**
 * Ускорение поверх ванильной физики: множитель к скорости, которую уже посчитала игра.
 * Boost 1.00 = ванильная скорость, чем выше - тем быстрее и тем заметнее для античита.
 */
public class Speed extends Module {
    private final NumSetting boost = add(new NumSetting("Boost", 1.10, 1.0, 1.6, 0.01));
    private final BoolSetting hop = add(new BoolSetting("Hop", true));
    private final BoolSetting airStrafe = add(new BoolSetting("AirStrafe", true));

    public Speed() {
        super("Speed", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        Move.run(mc().player, boost.get(), hop.get(), airStrafe.get());
    }
}
