package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;

/** Подсветка сущностей через клиентский флаг glowing (контур виден сквозь стены). */
public class ESP extends Module {
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting mobs = add(new BoolSetting("Mobs", false));

    public ESP() {
        super("ESP", Category.VISUAL);
    }

    @Override
    public void onTick() {
        for (Entity e : mc().world.getEntities()) {
            if (e == mc().player) {
                continue;
            }
            boolean want = (players.get() && e instanceof PlayerEntity) || (mobs.get() && e instanceof MobEntity);
            if (want) {
                e.setGlowing(true);
            } else if (e.isGlowing() && (e instanceof PlayerEntity || e instanceof MobEntity)) {
                e.setGlowing(false);
            }
        }
    }

    @Override
    public void onDisable() {
        if (mc().world == null) {
            return;
        }
        for (Entity e : mc().world.getEntities()) {
            if (e instanceof PlayerEntity || e instanceof MobEntity) {
                e.setGlowing(false);
            }
        }
    }
}
