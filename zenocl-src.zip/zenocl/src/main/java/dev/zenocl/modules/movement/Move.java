package dev.zenocl.modules.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.Vec3d;

/** Общая математика движения по нажатым клавишам и физика, согласованная с ванильной. */
final class Move {
    private Move() {
    }

    static boolean moving() {
        GameOptions o = MinecraftClient.getInstance().options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
    }

    /** Возвращает {x, z} единичного вектора движения в мировых координатах или {0,0}. */
    static double[] dir() {
        MinecraftClient mc = MinecraftClient.getInstance();
        GameOptions o = mc.options;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) {
            return new double[]{0, 0};
        }
        double yaw = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double x = -sin * f + cos * s;
        double z = cos * f + sin * s;
        double len = Math.sqrt(x * x + z * z);
        return new double[]{x / len, z / len};
    }

    /** Текущая горизонтальная скорость, блоков за тик. */
    static double speed(ClientPlayerEntity p) {
        Vec3d v = p.getVelocity();
        return Math.hypot(v.x, v.z);
    }

    /** Ванильная скорость ходьбы/спринта по земле с учётом эффектов Speed и Slowness. */
    static double base(ClientPlayerEntity p) {
        double b = p.isSprinting() ? 0.2873 : 0.2209;
        var fast = p.getStatusEffect(StatusEffects.SPEED);
        if (fast != null) {
            b *= 1.0 + 0.2 * (fast.getAmplifier() + 1);
        }
        var slow = p.getStatusEffect(StatusEffects.SLOWNESS);
        if (slow != null) {
            b *= Math.max(0.0, 1.0 - 0.15 * (slow.getAmplifier() + 1));
        }
        return b;
    }

    /** Состояния, где ванильная физика другая и вмешиваться нельзя. */
    static boolean blocked(ClientPlayerEntity p) {
        return p.isSneaking() || p.isTouchingWater() || p.isInLava() || p.isClimbing() || p.hasVehicle();
    }

    /** Задаёт горизонтальную скорость по направлению d, вертикальную не трогает. */
    static void set(ClientPlayerEntity p, double speed, double[] d) {
        Vec3d v = p.getVelocity();
        p.setVelocity(d[0] * speed, v.y, d[1] * speed);
    }

    /**
     * Один тик "ванильного" ускорения. Скорость не задаётся константой, а масштабируется от того, что
     * уже посчитала игра, поэтому трение (0.91 в воздухе, 0.546 на земле) продолжает работать как в ванили:
     * hop - прыжок на земле и множитель boost на взлёте; airStrafe - смена направления в воздухе без изменения модуля скорости.
     */
    static void run(ClientPlayerEntity p, double boost, boolean hop, boolean airStrafe) {
        if (!moving() || blocked(p)) {
            return;
        }
        double[] d = dir();
        if (p.isOnGround()) {
            if (hop) {
                p.jump();
                set(p, speed(p) * boost, d);
            } else if (boost > 1.0) {
                // потолок: иначе множитель копился бы каждый тик
                set(p, Math.min(speed(p) * boost, base(p) * boost), d);
            }
        } else if (airStrafe) {
            set(p, speed(p), d);
        }
    }
}
