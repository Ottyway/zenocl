package dev.zenocl.modules.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;

/** Общая математика движения по нажатым клавишам. */
final class Move {
    private Move() {
    }

    static boolean moving() {
        GameOptions o = MinecraftClient.getInstance().options;
        return o.forwardKey.isPressed() || o.backKey.isPressed() || o.leftKey.isPressed() || o.rightKey.isPressed();
    }

    /** Возвращает {x, z} единичного вектора движения в мировых координатах или {0,0}. */
    static double[] dir() {
        MinecraftClient mc = MinecraftClient.getInstance();
        GameOptions o = mc.options;
        double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
        double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
        if (f == 0 && s == 0) {
            return new double[]{0, 0};
        }
        double yaw = Math.toRadians(mc.player.getYaw());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double x = -sin * f + cos * s;
        double z = cos * f + sin * s;
        double len = Math.sqrt(x * x + z * z);
        return new double[]{x / len, z / len};
    }
}
