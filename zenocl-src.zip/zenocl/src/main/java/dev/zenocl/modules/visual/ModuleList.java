package dev.zenocl.modules.visual;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.ModuleManager;
import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Render;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ModuleList extends HudModule {
    private final BoolSetting background = add(new BoolSetting("Background", true));
    private final ModeSetting bar = add(new ModeSetting("Bar", "Right", "Right", "Left", "None"));
    private final BoolSetting lowercase = add(new BoolSetting("Lowercase", false));
    private final BoolSetting showBinds = add(new BoolSetting("ShowBinds", false));

    public ModuleList() {
        super("ArrayList");
    }

    private String label(Module m) {
        String n = lowercase.get() ? m.name.toLowerCase() : m.name;
        return showBinds.get() && m.getKey() != 0 ? n + " [" + dev.zenocl.gui.ClickGui.keyName(m.getKey()) + "]" : n;
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        List<Module> list = new ArrayList<>();
        for (Module m : ModuleManager.all()) {
            if (!(m instanceof HudModule) && !m.isSettingsOnly() && m.anim() > 0.01f) {
                list.add(m);
            }
        }
        list.sort(Comparator.comparingInt((Module m) -> Render.width(label(m))).reversed());

        int y = 6;
        int i = 0;
        for (Module m : list) {
            float a = m.anim();
            String text = label(m);
            int w = Render.width(text) + 10;
            int x = sw - 6 - (int) (w * a);
            int h = 13;
            int accent = Render.accent(i * 0.35);
            if (background.get()) {
                Render.rrect(ctx, x, y, w, h, Render.withAlpha(Render.bg(), a));
            }
            if (bar.is("Right")) {
                ctx.fill(x + w - 2, y + 2, x + w, y + h - 2, Render.withAlpha(accent, a));
            } else if (bar.is("Left")) {
                ctx.fill(x, y + 2, x + 2, y + h - 2, Render.withAlpha(accent, a));
            }
            Render.text(ctx, text, x + 5, y + 3, Render.withAlpha(accent, a));
            y += (int) ((h + 1) * Math.min(1f, a * 1.5f));
            i++;
        }
    }
}
