package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

/** Управление в воздухе: направление меняется сразу, скорость сохраняется. */
public class Strafe extends Module {
    private final NumSetting minSpeed = add(new NumSetting("MinSpeed", 0.2, 0.05, 0.6, 0.01));

    public Strafe() {
        super("Strafe", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (p.isOnGround() || !Move.moving() || p.isTouchingWater()) {
            return;
        }
        var v = p.getVelocity();
        double s = Math.max(Math.hypot(v.x, v.z), minSpeed.get());
        double[] d = Move.dir();
        p.setVelocity(d[0] * s, v.y, d[1] * s);
    }
}
