package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Во время длинного падения сообщает серверу, что игрок на земле, - урона от падения нет. */
public class NoFall extends Module {
    private final NumSetting distance = add(new NumSetting("Distance", 2.5, 1.0, 10.0, 0.5));

    public NoFall() {
        super("NoFall", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        if (!p.isOnGround() && p.fallDistance > distance.getFloat() && p.networkHandler != null) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
        }
    }
}
