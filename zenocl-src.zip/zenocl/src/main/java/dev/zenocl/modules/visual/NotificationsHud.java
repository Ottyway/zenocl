package dev.zenocl.modules.visual;

import dev.zenocl.hud.HudModule;
import dev.zenocl.hud.Notifications;
import dev.zenocl.hud.Render;
import net.minecraft.client.gui.DrawContext;

public class NotificationsHud extends HudModule {
    public NotificationsHud() {
        super("Notifications");
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh) {
        Notifications.cleanup();
        int y = sh - 40;
        for (int i = Notifications.ACTIVE.size() - 1; i >= 0; i--) {
            Notifications.Note n = Notifications.ACTIVE.get(i);
            long age = n.age();
            float in = Math.min(1f, age / 180f);
            float out = Math.min(1f, (Notifications.LIFETIME_MS - age) / 250f);
            float a = Math.max(0f, Math.min(in, out));

            String state = n.on ? "enabled" : "disabled";
            int w = Render.width(n.module) + Render.width(state) + 30;
            int h = 18;
            int x = sw - 8 - (int) (w * in) + (int) ((1f - out) * w);
            int col = n.on ? 0xFF55E58A : 0xFFFF5C6C;

            Render.rrect(ctx, x, y, w, h, Render.withAlpha(Render.bg(), a));
            ctx.fill(x + 2, y + 3, x + 4, y + h - 3, Render.withAlpha(col, a));
            Render.text(ctx, n.module, x + 9, y + 5, Render.withAlpha(Render.TEXT, a));
            Render.text(ctx, state, x + 14 + Render.width(n.module), y + 5, Render.withAlpha(col, a));
            y -= h + 3;
        }
    }
}
