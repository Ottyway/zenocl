package dev.zenocl.modules.movement;

import dev.zenocl.core.Category;
import dev.zenocl.core.Module;
import dev.zenocl.core.NumSetting;

public class Fly extends Module {
    private final NumSetting speed = add(new NumSetting("Speed", 0.6, 0.1, 3.0, 0.05));
    private final NumSetting vertical = add(new NumSetting("Vertical", 0.5, 0.1, 2.0, 0.05));

    public Fly() {
        super("Fly", Category.MOVEMENT);
    }

    @Override
    public void onTick() {
        var p = mc().player;
        double[] d = Move.dir();
        double y = 0;
        if (mc().options.jumpKey.isPressed()) {
            y += vertical.get();
        }
        if (mc().options.sneakKey.isPressed()) {
            y -= vertical.get();
        }
        p.setVelocity(d[0] * speed.get(), y, d[1] * speed.get());
        p.fallDistance = 0f;
    }
}
