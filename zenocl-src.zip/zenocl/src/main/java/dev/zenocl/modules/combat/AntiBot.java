package dev.zenocl.modules.combat;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModuleManager;
import dev.zenocl.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

/** Отсеивает ботов-пустышек анти-читов: нет записи в табе или невозможный ник. */
public class AntiBot extends Module {
    private final BoolSetting tab = add(new BoolSetting("TabCheck", true));
    private final BoolSetting name = add(new BoolSetting("NameCheck", true));

    public AntiBot() {
        super("AntiBot", Category.COMBAT);
    }

    public static boolean isBot(PlayerEntity pl) {
        AntiBot self = ModuleManager.get(AntiBot.class);
        if (!self.isEnabled()) {
            return false;
        }
        var net = MinecraftClient.getInstance().getNetworkHandler();
        if (self.tab.get() && net != null && net.getPlayerListEntry(pl.getUuid()) == null) {
            return true;
        }
        return self.name.get() && !pl.getName().getString().matches("[A-Za-z0-9_]{3,16}");
    }
}
