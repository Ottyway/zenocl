package dev.zenocl.gui;

import dev.zenocl.core.BoolSetting;
import dev.zenocl.core.Category;
import dev.zenocl.core.ModeSetting;
import dev.zenocl.core.Module;
import dev.zenocl.core.ModuleManager;
import dev.zenocl.core.NumSetting;
import dev.zenocl.core.Setting;
import dev.zenocl.hud.Icon3D;
import dev.zenocl.hud.Render;
import dev.zenocl.hud.Theme;
import dev.zenocl.modules.misc.ClientSettings;
import dev.zenocl.util.Friends;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ClickGUI ZenoCL: сайдбар с категориями, поиск, секции в два столбца, всплывающая панель настроек.
 * Тёмно-алая тема, дешёвая отрисовка (только прямоугольники, аура из нескольких статичных слоёв).
 */
public class ClickGui extends Screen {
    private static final int SIDE = 106;
    private static final int ROW = 19;
    private static final int HEAD = 21;
    private static final int PAGE_PRESETS = 5;
    private static final int PAGE_CONFIG = 6;
    private static final int SEARCH_SCROLL = 7;
    private static final int DIM = 0xFF8D868C;
    private static final int FAINT = 0xFF5A5358;
    private static final int[] SEARCH_KEYS = searchKeys();

    private int page = 0;
    private final float[] scroll = new float[8];
    private float maxScroll;

    private Module popupMod;
    private int popupAx;
    private int popupAy;
    private int pX;
    private int pY;
    private int pW;
    private int pH;
    private float popupScroll;
    private float popupShown;
    private long closingAt;
    private final float[] shownScroll = new float[8];
    private final float[] selAnim = new float[8];
    private final java.util.Map<Object, Float> switchAnim = new java.util.IdentityHashMap<>();
    private final long openedAt = System.nanoTime();
    private long lastFrame = System.nanoTime();
    private float frameDt;
    private int lastView = -1;
    private long viewAt = System.nanoTime();
    private int popupFullH;
    private boolean openedThisFrame;
    private boolean overPopup;

    private Module listening;
    private NumSetting dragging;
    private int dragX;
    private int dragW;

    private boolean searching;
    private final StringBuilder query = new StringBuilder();
    private final boolean[] prevKey = new boolean[GLFW.GLFW_KEY_LAST + 1];

    private boolean prevL;
    private boolean prevR;
    private boolean prevM;
    private boolean prevShift = true;
    private boolean prevEsc;
    private int mx;
    private int my;
    private boolean cl;
    private boolean cr;
    private boolean cm;

    private String toast = "";
    private long toastAt;

    public ClickGui() {
        super(Text.literal("ZenoCL"));
    }

    private static int[] searchKeys() {
        int[] k = new int[26 + 10 + 2];
        int n = 0;
        for (int c = GLFW.GLFW_KEY_A; c <= GLFW.GLFW_KEY_Z; c++) {
            k[n++] = c;
        }
        for (int c = GLFW.GLFW_KEY_0; c <= GLFW.GLFW_KEY_9; c++) {
            k[n++] = c;
        }
        k[n++] = GLFW.GLFW_KEY_SPACE;
        k[n] = GLFW.GLFW_KEY_BACKSPACE;
        return k;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return listening == null && !searching;
    }

    /** Закрытие идёт через короткую анимацию: реальный close() вызывается из render(). */
    @Override
    public void close() {
        if (closingAt == 0) {
            closingAt = System.nanoTime();
        }
    }

    @Override
    public void removed() {
        ModuleManager.save();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        if (popupMod != null && overPopup) {
            popupScroll = Math.max(0f, Math.min(Math.max(0, popupFullH - pH), popupScroll - (float) vertical * 14f));
            return true;
        }
        int i = query.length() > 0 ? SEARCH_SCROLL : page;
        scroll[i] = Math.max(0f, Math.min(maxScroll, scroll[i] - (float) vertical * 18f));
        return true;
    }

    // ------------------------------------------------------------------ цвета

    private static int tint(float f) {
        return 0xFF000000 | Theme.dark(f);
    }

    private static int acc() {
        return Render.accent(0);
    }

    private static boolean in(int px, int py, int x, int y, int w, int h) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    // ------------------------------------------------------------------ главный цикл

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        long nowN = System.nanoTime();
        frameDt = Math.min(0.05f, (nowN - lastFrame) / 1.0e9f);
        lastFrame = nowN;
        float open = ease(Math.min(1f, (nowN - openedAt) / 2.4e8f));
        if (closingAt != 0) {
            float cp = (nowN - closingAt) / 1.6e8f;
            if (cp >= 1f) {
                super.close();
                return;
            }
            open = Math.min(open, 1f - ease(cp));
        }
        int view = query.length() > 0 ? SEARCH_SCROLL : page;
        if (view != lastView) {
            lastView = view;
            viewAt = nowN;
        }
        // экспоненциальное сглаживание: от частоты кадров не зависит
        float k = 1f - (float) Math.exp(-frameDt * 16f);
        for (int i = 0; i < shownScroll.length; i++) {
            shownScroll[i] += (scroll[i] - shownScroll[i]) * k;
        }
        popupShown += (popupScroll - popupShown) * k;

        long win = MinecraftClient.getInstance().getWindow().getHandle();
        boolean l = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean m = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
        cl = l && !prevL;
        cr = r && !prevR;
        cm = m && !prevM;
        prevL = l;
        prevR = r;
        prevM = m;
        mx = mouseX;
        my = mouseY;

        boolean shift = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (shift && !prevShift && listening == null) {
            prevShift = true;
            close();
            return;
        }
        prevShift = shift;

        pollKeys(win);
        if (dragging != null) {
            if (!l) {
                dragging = null;
            } else {
                double t = Math.max(0, Math.min(1, (mx - dragX) / (double) dragW));
                dragging.set(dragging.min + t * (dragging.max - dragging.min));
            }
        }
        openedThisFrame = false;
        overPopup = popupMod != null && in(mx, my, pX, pY, pW, pH);

        int w = Math.min(430, width - 12);
        int h = Math.min(292, height - 12);
        int x0 = (width - w) / 2;
        int y0 = (height - h) / 2 + (int) ((1f - open) * 18f);

        ctx.fill(0, 0, width, height, ((int) (0x77 * open) << 24));
        drawWindow(ctx, x0, y0, w, h);
        drawSidebar(ctx, x0, y0, h);
        drawContent(ctx, x0 + SIDE + 10, y0, w - SIDE - 20, h);
        drawPopup(ctx, x0, y0, w, h);

        if (cl || cr) {
            if (popupMod != null && !overPopup && !openedThisFrame) {
                popupMod = null;
            }
        }
    }

    private void drawWindow(DrawContext ctx, int x0, int y0, int w, int h) {
        // аура: несколько статичных полупрозрачных слоёв с лёгкой пульсацией
        float pulse = (float) (0.8 + 0.2 * Math.sin(System.currentTimeMillis() / 900.0));
        int a = acc();
        for (int i = 3; i >= 1; i--) {
            Render.rrect(ctx, x0 - i * 3, y0 - i * 3, w + i * 6, h + i * 6, Render.withAlpha(a, 0.05f * pulse / (i * 0.8f)));
        }
        Render.rrect(ctx, x0 - 1, y0 - 1, w + 2, h + 2, Render.withAlpha(a, 0.5f));
        Render.rrect(ctx, x0, y0, w, h, tint(0.055f));
        ctx.fillGradient(x0 + 2, y0 + 2, x0 + w - 2, y0 + 52, Render.withAlpha(a, 0.13f), Render.withAlpha(a, 0f));
        ctx.fill(x0 + SIDE, y0 + 10, x0 + SIDE + 1, y0 + h - 10, 0x14FFFFFF);
        if (y0 >= 12) {
            String t = "Меню";
            Render.text(ctx, t, x0 + w / 2 - Render.width(t) / 2, y0 - 11, DIM);
        }
    }

    // ------------------------------------------------------------------ сайдбар

    private static final String[] CAT_TITLES = {"Бой", "Движение", "Визуалы", "Игрок", "Разное"};

    private void drawSidebar(DrawContext ctx, int x0, int y0, int h) {
        Icon3D.draw(ctx, x0 + 24, y0 + 24, 15f, 0.0);
        Render.text(ctx, "ZenoCL", x0 + 42, y0 + 19, acc());

        Render.text(ctx, "ФУНКЦИИ", x0 + 14, y0 + 48, FAINT);
        int y = y0 + 61;
        for (int i = 0; i < Category.values().length; i++) {
            sideItem(ctx, x0, y, i, CAT_TITLES[i]);
            y += 22;
        }
        y += 8;
        Render.text(ctx, "УПРАВЛЕНИЕ", x0 + 14, y, FAINT);
        y += 13;
        sideItem(ctx, x0, y, PAGE_PRESETS, "Пресеты");
        y += 22;
        sideItem(ctx, x0, y, PAGE_CONFIG, "Конфиг");

        // профиль внизу
        String name = MinecraftClient.getInstance().getSession().getUsername();
        int py = y0 + h - 32;
        Render.rrect(ctx, x0 + 10, py, 22, 22, Render.withAlpha(acc(), 0.22f));
        String ini = name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase();
        Render.text(ctx, ini, x0 + 21 - Render.width(ini) / 2, py + 7, 0xFFFFFFFF);
        Render.text(ctx, name, x0 + 38, py + 3, 0xFFE8E2E6);
        Render.text(ctx, "ZenoCL 1.21.11", x0 + 38, py + 13, FAINT);
    }

    private void sideItem(DrawContext ctx, int x0, int y, int idx, String title) {
        boolean sel = page == idx && query.length() == 0;
        boolean hover = in(mx, my, x0 + 7, y, SIDE - 14, 20);
        selAnim[idx] += ((sel ? 1f : 0f) - selAnim[idx]) * (1f - (float) Math.exp(-frameDt * 14f));
        float sa = selAnim[idx];
        if (sa > 0.02f) {
            Render.rrect(ctx, x0 + 7, y, SIDE - 14, 20, Render.withAlpha(acc(), 0.16f * sa));
            ctx.fill(x0 + 7, y + 4, x0 + 9, y + 16, Render.withAlpha(acc(), sa));
        } else if (hover) {
            Render.rrect(ctx, x0 + 7, y, SIDE - 14, 20, 0x10FFFFFF);
        }
        int col = Render.lerp(hover ? 0xFFFFFFFF : DIM, acc(), sa);
        icon(ctx, idx, x0 + 15, y + 5, col);
        Render.text(ctx, title, x0 + 31, y + 6, col);
        if (hover && cl) {
            page = idx;
            popupMod = null;
            searching = false;
            query.setLength(0);
        }
    }

    /** Маленькие 9x9 иконки из прямоугольников. */
    private static void icon(DrawContext ctx, int idx, int x, int y, int c) {
        switch (idx) {
            case 0 -> { // меч
                for (int i = 0; i < 8; i++) {
                    ctx.fill(x + 1 + i, y + 7 - i, x + 3 + i, y + 8 - i, c);
                }
                ctx.fill(x + 1, y + 5, x + 5, y + 6, c);
                ctx.fill(x, y + 8, x + 2, y + 9, c);
            }
            case 1 -> { // стрелки
                ctx.fill(x + 4, y + 1, x + 5, y + 8, c);
                ctx.fill(x + 1, y + 4, x + 8, y + 5, c);
                ctx.fill(x + 4, y, x + 5, y + 1, c);
                ctx.fill(x + 3, y + 1, x + 6, y + 2, c);
                ctx.fill(x + 3, y + 7, x + 6, y + 8, c);
                ctx.fill(x + 4, y + 8, x + 5, y + 9, c);
                ctx.fill(x, y + 4, x + 1, y + 5, c);
                ctx.fill(x + 1, y + 3, x + 2, y + 6, c);
                ctx.fill(x + 8, y + 4, x + 9, y + 5, c);
                ctx.fill(x + 7, y + 3, x + 8, y + 6, c);
            }
            case 2 -> { // глаз
                ctx.fill(x + 2, y + 2, x + 7, y + 3, c);
                ctx.fill(x + 1, y + 3, x + 2, y + 4, c);
                ctx.fill(x + 7, y + 3, x + 8, y + 4, c);
                ctx.fill(x, y + 4, x + 1, y + 5, c);
                ctx.fill(x + 8, y + 4, x + 9, y + 5, c);
                ctx.fill(x + 1, y + 5, x + 2, y + 6, c);
                ctx.fill(x + 7, y + 5, x + 8, y + 6, c);
                ctx.fill(x + 2, y + 6, x + 7, y + 7, c);
                ctx.fill(x + 4, y + 3, x + 5, y + 6, c);
            }
            case 3 -> { // игрок
                ctx.fill(x + 3, y, x + 6, y + 4, c);
                ctx.fill(x + 2, y + 5, x + 7, y + 6, c);
                ctx.fill(x + 1, y + 6, x + 8, y + 9, c);
            }
            case 4 -> { // ветка
                ctx.fill(x + 1, y + 1, x + 3, y + 3, c);
                ctx.fill(x + 1, y + 6, x + 3, y + 8, c);
                ctx.fill(x + 6, y + 3, x + 8, y + 5, c);
                ctx.fill(x + 2, y + 3, x + 3, y + 6, c);
                ctx.fill(x + 3, y + 4, x + 6, y + 5, c);
            }
            case PAGE_PRESETS -> { // ползунки
                ctx.fill(x, y + 1, x + 9, y + 2, c);
                ctx.fill(x + 2, y, x + 4, y + 3, c);
                ctx.fill(x, y + 4, x + 9, y + 5, c);
                ctx.fill(x + 5, y + 3, x + 7, y + 6, c);
                ctx.fill(x, y + 7, x + 9, y + 8, c);
                ctx.fill(x + 1, y + 6, x + 3, y + 9, c);
            }
            default -> { // дискета
                ctx.fill(x, y, x + 9, y + 1, c);
                ctx.fill(x, y + 8, x + 9, y + 9, c);
                ctx.fill(x, y, x + 1, y + 9, c);
                ctx.fill(x + 8, y, x + 9, y + 9, c);
                ctx.fill(x + 2, y + 1, x + 7, y + 3, c);
                ctx.fill(x + 2, y + 5, x + 7, y + 8, c);
            }
        }
    }

    // ------------------------------------------------------------------ контент

    private void drawContent(DrawContext ctx, int cx, int y0, int cw, int h) {
        drawSearch(ctx, cx, y0 + 9, cw);

        int cy = y0 + 38;
        int ch = h - 46;
        boolean results = query.length() > 0;
        int si = results ? SEARCH_SCROLL : page;
        boolean inClip = in(mx, my, cx - 2, cy, cw + 4, ch);

        float viewEase = ease(Math.min(1f, (System.nanoTime() - viewAt) / 2.0e8f));
        int off = Math.round(shownScroll[si]) - (int) ((1f - viewEase) * 14f);
        int[] colY = {cy - off, cy - off};
        ctx.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
        if (!results && page == PAGE_PRESETS) {
            drawPresets(ctx, cx, cy - off, cw, inClip, colY);
        } else if (!results && page == PAGE_CONFIG) {
            drawConfig(ctx, cx, cy - off, cw, inClip, colY);
        } else {
            drawModules(ctx, cx, cy, ch, cw, inClip, results, colY);
        }
        ctx.disableScissor();

        float total = Math.max(colY[0], colY[1]) - (cy - off) - 8;
        maxScroll = Math.max(0, total - ch);
        scroll[si] = Math.min(scroll[si], maxScroll);
    }

    private void drawSearch(DrawContext ctx, int cx, int sy, int cw) {
        int sbw = cw - 30;
        boolean hover = in(mx, my, cx, sy, sbw, 20);
        if (searching) {
            Render.rrect(ctx, cx - 1, sy - 1, sbw + 2, 22, Render.withAlpha(acc(), 0.55f));
        }
        Render.rrect(ctx, cx, sy, sbw, 20, tint(searching ? 0.16f : 0.11f));
        // лупа
        int lx = cx + 8, ly = sy + 6;
        int c = searching ? acc() : FAINT;
        ctx.fill(lx + 1, ly, lx + 4, ly + 1, c);
        ctx.fill(lx + 1, ly + 4, lx + 4, ly + 5, c);
        ctx.fill(lx, ly + 1, lx + 1, ly + 4, c);
        ctx.fill(lx + 4, ly + 1, lx + 5, ly + 4, c);
        ctx.fill(lx + 5, ly + 5, lx + 7, ly + 7, c);

        String text;
        int tc;
        if (query.length() == 0 && !searching) {
            text = "Поиск";
            tc = FAINT;
        } else {
            boolean caret = searching && (System.currentTimeMillis() / 450) % 2 == 0;
            text = query + (caret ? "|" : "");
            tc = 0xFFFFFFFF;
        }
        Render.text(ctx, text, cx + 22, sy + 6, tc);

        // кнопка-меню справа
        int bx = cx + sbw + 5;
        Render.rrect(ctx, bx, sy, 25, 20, tint(0.11f));
        for (int i = 0; i < 3; i++) {
            ctx.fill(bx + 8, sy + 6 + i * 3, bx + 17, sy + 7 + i * 3, DIM);
        }
        if (cl) {
            searching = hover;
            if (hover) {
                listening = null;
            }
        }
    }

    private static String sectionOf(Module m) {
        return switch (m.name) {
            case "KillAura", "TriggerBot", "AimAssist" -> "Драка";
            case "AutoCrystal" -> "Кристаллы";
            case "AutoTotem", "AutoGapple", "Velocity" -> "Защита";
            case "AntiBot", "Surround", "AutoLog", "AutoPot", "AutoXP", "PearlThrow" -> "Тактика";
            case "BowAim" -> "Дальний бой";
            case "Sprint", "Speed", "TargetStrafe" -> "Скорость";
            case "Fly", "Glide" -> "Полёт";
            case "Jesus", "Spider", "Step", "AutoWalk" -> "Перемещение";
            case "Bhop", "Strafe", "HighJump", "AirJump", "FastFall", "AntiVoid", "NoFall" -> "Прыжки";
            case "ESP", "Fullbright", "Zoom" -> "Мир";
            case "AutoArmor", "ChestStealer", "AutoEat" -> "Инвентарь";
            case "FastPlace", "AutoRespawn", "AutoSneak", "AutoMine", "MiddleClickFriend" -> "Действия";
            case "Client" -> "Клиент";
            case "AntiAFK", "Spammer", "Panic" -> "Прочее";
            default -> m.category == Category.VISUAL ? "Интерфейс" : "Прочее";
        };
    }

    private void drawModules(DrawContext ctx, int cx, int cy, int ch, int cw, boolean inClip, boolean results, int[] colY) {
        Map<String, List<Module>> secs = new LinkedHashMap<>();
        if (results) {
            String q = query.toString().toLowerCase();
            List<Module> found = new ArrayList<>();
            for (Module m : ModuleManager.all()) {
                if (m.name.toLowerCase().contains(q)) {
                    found.add(m);
                }
            }
            if (!found.isEmpty()) {
                secs.put("Результаты", found);
            }
        } else {
            for (Module m : ModuleManager.byCategory(Category.values()[page])) {
                secs.computeIfAbsent(sectionOf(m), k -> new ArrayList<>()).add(m);
            }
        }
        if (secs.isEmpty()) {
            Render.text(ctx, "Ничего не найдено", cx + 4, cy + 6, FAINT);
            return;
        }

        int colW = (cw - 10) / 2;
        for (Map.Entry<String, List<Module>> e : secs.entrySet()) {
            int c = colY[1] < colY[0] ? 1 : 0;
            int x = cx + c * (colW + 10);
            int y = colY[c];
            List<Module> list = e.getValue();
            int ph = HEAD + list.size() * ROW + 4;
            if (y + ph >= cy && y <= cy + ch) {
                Render.rrect(ctx, x, y, colW, ph, tint(0.105f));
                Render.text(ctx, e.getKey(), x + 10, y + 6, acc());
                chevron(ctx, x + colW - 15, y + 5, acc());
                for (int i = 0; i < list.size(); i++) {
                    int ry = y + HEAD + i * ROW;
                    if (ry + ROW >= cy && ry <= cy + ch) {
                        drawRow(ctx, list.get(i), x, ry, colW, inClip, i < list.size() - 1);
                    }
                }
            }
            colY[c] = y + ph + 8;
        }
    }

    private void drawRow(DrawContext ctx, Module mod, int x, int ry, int colW, boolean inClip, boolean sep) {
        boolean only = mod.isSettingsOnly();
        float a = only ? 0f : mod.anim();
        boolean hover = inClip && !overPopup && in(mx, my, x, ry, colW, ROW);
        if (hover) {
            ctx.fill(x + 4, ry, x + colW - 4, ry + ROW, 0x0AFFFFFF);
        }
        if (a > 0.01f) {
            ctx.fill(x + 4, ry, x + colW - 4, ry + ROW, Render.withAlpha(acc(), 0.10f * a));
        }
        Render.text(ctx, mod.name, x + 10 + (int) (a * 2), ry + 5, Render.lerp(DIM, 0xFFFFFFFF, only ? 0.7f : a));

        int sw = 22, sh = 11;
        int sx = x + colW - sw - 9;
        if (!only) {
            pill(ctx, sx, ry + 4, sw, sh, a);
        }
        int dx = only ? x + colW - 24 : sx - 17;
        boolean dotsHover = hover && mx >= dx - 3 && mx < dx + 13;
        int dc = popupMod == mod ? acc() : (dotsHover ? 0xFFFFFFFF : FAINT);
        for (int k = 0; k < 3; k++) {
            ctx.fill(dx + k * 4, ry + 9, dx + k * 4 + 2, ry + 11, dc);
        }
        if (mod.getKey() != 0) {
            String kn = keyName(mod.getKey());
            Render.text(ctx, kn, dx - 5 - Render.width(kn), ry + 5, Render.withAlpha(acc(), 0.8f));
        }
        if (sep) {
            ctx.fill(x + 9, ry + ROW - 1, x + colW - 9, ry + ROW, 0x0EFFFFFF);
        }

        if (hover) {
            if (cl) {
                if (dotsHover || only) {
                    togglePopup(mod, dx, ry);
                } else {
                    mod.toggle();
                }
            } else if (cr) {
                togglePopup(mod, dx, ry);
            } else if (cm) {
                popupMod = mod;
                popupScroll = 0;
        popupShown = 0;
                popupAx = dx;
                popupAy = ry;
                openedThisFrame = true;
                listening = mod;
                searching = false;
            }
        }
    }

    private void togglePopup(Module mod, int ax, int ay) {
        popupMod = popupMod == mod ? null : mod;
        popupScroll = 0;
        popupShown = 0;
        popupAx = ax;
        popupAy = ay;
        openedThisFrame = true;
    }

    private static void chevron(DrawContext ctx, int x, int y, int c) {
        ctx.fill(x + 2, y, x + 3, y + 1, c);
        ctx.fill(x + 1, y + 1, x + 4, y + 2, c);
        ctx.fill(x, y + 2, x + 5, y + 3, c);
        ctx.fill(x, y + 5, x + 5, y + 6, c);
        ctx.fill(x + 1, y + 6, x + 4, y + 7, c);
        ctx.fill(x + 2, y + 7, x + 3, y + 8, c);
    }

    private static float ease(float t) {
        float u = 1f - t;
        return 1f - u * u * u;
    }

    /** Плавное значение переключателя настройки 0..1 со сглаженной кривой. */
    private float boolAnim(BoolSetting b) {
        float target = b.get() ? 1f : 0f;
        float v = switchAnim.getOrDefault(b, target);
        float step = frameDt * 6f;
        v = v < target ? Math.min(target, v + step) : Math.max(target, v - step);
        switchAnim.put(b, v);
        return v * v * (3f - 2f * v);
    }

    private static void pill(DrawContext ctx, int x, int y, int w, int h, float a) {
        Render.rrect(ctx, x, y, w, h, Render.lerp(0xFF2D2528, acc(), a));
        int k = h - 4;
        int stretch = (int) (Math.sin(Math.PI * a) * 3);
        int kx = x + 2 + (int) ((w - k - 4 - stretch) * a);
        ctx.fill(kx, y + 2, kx + k + stretch, y + 2 + k, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------------ страницы "Пресеты" и "Конфиг"

    private void drawPresets(DrawContext ctx, int cx, int top, int cw, boolean inClip, int[] colY) {
        String[] names = Theme.names();
        String current = ClientSettings.INSTANCE.theme.get();
        int rows = (names.length + 1) / 2;
        int ph = HEAD + rows * 33 + 4;
        Render.rrect(ctx, cx, top, cw, ph, tint(0.105f));
        Render.text(ctx, "Темы", cx + 10, top + 6, acc());
        chevron(ctx, cx + cw - 15, top + 5, acc());

        int cardW = (cw - 26) / 2;
        for (int i = 0; i < names.length; i++) {
            int x = cx + 9 + (i % 2) * (cardW + 8);
            int y = top + HEAD + (i / 2) * 33;
            boolean sel = names[i].equalsIgnoreCase(current);
            boolean hover = inClip && in(mx, my, x, y, cardW, 28);
            if (sel) {
                Render.rrect(ctx, x - 1, y - 1, cardW + 2, 30, Render.withAlpha(acc(), 0.7f));
            }
            Render.rrect(ctx, x, y, cardW, 28, tint(hover ? 0.19f : 0.14f));
            swatch(ctx, names[i], x + 8, y + 9);
            Render.text(ctx, names[i], x + 34, y + 10, sel ? 0xFFFFFFFF : DIM);
            if (hover && cl) {
                ClientSettings.INSTANCE.theme.deserialize(names[i]);
            }
        }
        int y = top + ph + 8;
        int rh = ROW * 1 + 8;
        Render.rrect(ctx, cx, y, cw, rh, tint(0.105f));
        drawRow(ctx, ClientSettings.INSTANCE, cx, y + 4, cw, inClip, false);
        colY[0] = y + rh + 8;
        colY[1] = colY[0];
    }

    private static void swatch(DrawContext ctx, String name, int x, int y) {
        for (Theme.T t : Theme.all()) {
            if (!t.name().equals(name)) {
                continue;
            }
            if (Theme.rainbow(t)) {
                for (int i = 0; i < 6; i++) {
                    ctx.fill(x + i * 3, y, x + i * 3 + 3, y + 10, Theme.hsv(i / 6f, 0.6f, 1f));
                }
            } else {
                ctx.fill(x, y, x + 9, y + 10, t.a());
                ctx.fill(x + 9, y, x + 18, y + 10, t.b());
            }
            return;
        }
    }

    private void drawConfig(DrawContext ctx, int cx, int top, int cw, boolean inClip, int[] colY) {
        int ph = HEAD + 34;
        Render.rrect(ctx, cx, top, cw, ph, tint(0.105f));
        Render.text(ctx, "Конфиг", cx + 10, top + 6, acc());
        chevron(ctx, cx + cw - 15, top + 5, acc());
        int bw = (cw - 26) / 2;
        configButton(ctx, cx + 9, top + HEAD, bw, "Сохранить", inClip, true);
        configButton(ctx, cx + 17 + bw, top + HEAD, bw, "Загрузить", inClip, false);

        int y = top + ph + 8;
        List<String> lines = new ArrayList<>();
        lines.add(Friends.all().isEmpty() ? "Друзей нет" : "Друзья: " + String.join(", ", Friends.all()));
        lines.add(".friend add Ник  -  добавить друга");
        lines.add(".bind add \"KillAura\" \"R\"  -  бинд");
        lines.add(".set TargetStrafe Radius 3  -  настройка");
        lines.add(".help  -  все команды");
        int hh = HEAD + lines.size() * 13 + 6;
        Render.rrect(ctx, cx, y, cw, hh, tint(0.105f));
        Render.text(ctx, "Друзья и команды", cx + 10, y + 6, acc());
        for (int i = 0; i < lines.size(); i++) {
            Render.text(ctx, lines.get(i), cx + 12, y + HEAD + i * 13, i == 0 ? 0xFFE8E2E6 : DIM);
        }
        if (!toast.isEmpty() && System.currentTimeMillis() - toastAt < 1800) {
            Render.text(ctx, toast, cx + cw - 10 - Render.width(toast), top + 6, 0xFF55E58A);
        }
        colY[0] = y + hh + 8;
        colY[1] = colY[0];
    }

    private void configButton(DrawContext ctx, int x, int y, int w, String label, boolean inClip, boolean save) {
        boolean hover = inClip && in(mx, my, x, y, w, 24);
        Render.rrect(ctx, x, y, w, 24, hover ? Render.withAlpha(acc(), 0.28f) : tint(0.16f));
        Render.text(ctx, label, x + w / 2 - Render.width(label) / 2, y + 8, hover ? 0xFFFFFFFF : DIM);
        if (hover && cl) {
            if (save) {
                ModuleManager.save();
                toast = "Сохранено";
            } else {
                ModuleManager.load();
                toast = "Загружено";
            }
            toastAt = System.currentTimeMillis();
        }
    }

    // ------------------------------------------------------------------ всплывающая панель настроек

    private void drawPopup(DrawContext ctx, int x0, int y0, int w, int h) {
        if (popupMod == null) {
            return;
        }
        Module m = popupMod;
        int ph = 22 + 18 + 6;
        for (Setting<?> s : m.settings) {
            ph += s instanceof NumSetting ? 27 : 18;
        }
        int pw = 180;
        int vh = Math.min(ph, height - 12);
        boolean right = x0 + w + 8 + pw <= width;
        boolean left = x0 - 8 - pw >= 0;
        int px;
        int py;
        if (right || left) {
            // отдельная панель рядом с окном, на уровне нажатой строки - ничего не перекрывает
            px = right ? x0 + w + 8 : x0 - 8 - pw;
            py = Math.max(6, Math.min(height - vh - 6, popupAy));
        } else {
            px = Math.max(x0 + SIDE + 6, Math.min(x0 + w - pw - 6, popupAx + 14 - pw));
            py = Math.max(y0 + 6, Math.min(y0 + h - vh - 6, popupAy + ROW));
        }
        pX = px;
        pY = py;
        pW = pw;
        pH = vh;
        popupFullH = ph;
        popupScroll = Math.max(0f, Math.min(popupScroll, Math.max(0, ph - vh)));
        boolean inPop = in(mx, my, px, py + 21, pw, vh - 21);

        Render.rrect(ctx, px - 2, py - 2, pw + 4, vh + 4, Render.withAlpha(acc(), 0.22f));
        Render.rrect(ctx, px, py, pw, vh, 0xFA000000 | Theme.dark(0.085f));
        Render.text(ctx, m.name, px + 10, py + 7, acc());
        ctx.fill(px + 8, py + 19, px + pw - 8, py + 20, 0x14FFFFFF);

        int ix = px + 10;
        int iw = pw - 20;
        int y = py + 22 - Math.round(popupShown);

        if (ph > vh) {
            int track = vh - 26;
            int th = Math.max(12, track * vh / ph);
            int ty = py + 24 + (int) ((track - th) * (Math.min(1f, popupShown / (float) (ph - vh))));
            ctx.fill(px + pw - 4, ty, px + pw - 2, ty + th, Render.withAlpha(acc(), 0.7f));
        }
        ctx.enableScissor(px, py + 21, px + pw, py + vh);

        // бинд
        {
            boolean hov = inPop && in(mx, my, px, y, pw, 17);
            String v = listening == m ? "нажми клавишу..." : keyName(m.getKey());
            Render.text(ctx, "Bind", ix, y + 4, 0xFFCFC9CD);
            Render.text(ctx, v, ix + iw - Render.width(v), y + 4, listening == m ? acc() : DIM);
            if (hov && cl) {
                listening = m;
                searching = false;
            }
            y += 18;
        }

        for (Setting<?> s : m.settings) {
            if (s instanceof BoolSetting b) {
                boolean hov = inPop && in(mx, my, px, y, pw, 17);
                Render.text(ctx, b.name, ix, y + 4, 0xFFCFC9CD);
                pill(ctx, ix + iw - 20, y + 3, 20, 11, boolAnim(b));
                if (hov && cl) {
                    b.toggle();
                }
                y += 18;
            } else if (s instanceof ModeSetting ms) {
                boolean hov = inPop && in(mx, my, px, y, pw, 17);
                Render.text(ctx, ms.name, ix, y + 4, 0xFFCFC9CD);
                Render.text(ctx, ms.get(), ix + iw - Render.width(ms.get()), y + 4, acc());
                if (hov && cl) {
                    ms.cycle();
                }
                y += 18;
            } else if (s instanceof NumSetting n) {
                boolean hov = inPop && in(mx, my, px, y, pw, 26);
                String v = n.step >= 1 ? Integer.toString(n.getInt()) : String.format("%.2f", n.get());
                Render.text(ctx, n.name, ix, y + 4, 0xFFCFC9CD);
                Render.text(ctx, v, ix + iw - Render.width(v), y + 4, 0xFFFFFFFF);
                int sy = y + 17;
                ctx.fill(ix, sy, ix + iw, sy + 3, 0xFF2D2528);
                int fill = (int) (iw * n.progress());
                ctx.fillGradient(ix, sy, ix + Math.max(1, fill), sy + 3, Render.accent(0), Render.accent(1.5));
                ctx.fill(ix + fill - 1, sy - 1, ix + fill + 1, sy + 4, 0xFFFFFFFF);
                if (hov && cl) {
                    dragging = n;
                    dragX = ix;
                    dragW = iw;
                }
                y += 27;
            }
        }
        ctx.disableScissor();
    }

    // ------------------------------------------------------------------ ввод с клавиатуры (без событий Screen)

    private static boolean down(long win, int key) {
        return GLFW.glfwGetKey(win, key) == GLFW.GLFW_PRESS;
    }

    private void pollKeys(long win) {
        boolean esc = down(win, GLFW.GLFW_KEY_ESCAPE);
        if (esc && !prevEsc) {
            if (listening != null) {
                listening = null;
            } else if (searching) {
                searching = false;
            }
        }
        prevEsc = esc;

        if (listening != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                if (k != GLFW.GLFW_KEY_ESCAPE && down(win, k)) {
                    listening.setKey(k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE ? 0 : k);
                    listening = null;
                    break;
                }
            }
        }

        for (int k : SEARCH_KEYS) {
            boolean d = down(win, k);
            if (d && !prevKey[k] && searching && listening == null) {
                if (k == GLFW.GLFW_KEY_BACKSPACE) {
                    if (query.length() > 0) {
                        query.setLength(query.length() - 1);
                    }
                } else if (query.length() < 18) {
                    if (k == GLFW.GLFW_KEY_SPACE) {
                        query.append(' ');
                    } else if (k >= GLFW.GLFW_KEY_A && k <= GLFW.GLFW_KEY_Z) {
                        query.append((char) (k + 32));
                    } else {
                        query.append((char) k);
                    }
                }
            }
            prevKey[k] = d;
        }
    }

    public static String keyName(int k) {
        if (k == 0) {
            return "NONE";
        }
        switch (k) {
            case GLFW.GLFW_KEY_SPACE: return "SPACE";
            case GLFW.GLFW_KEY_TAB: return "TAB";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT: return "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "RALT";
            case GLFW.GLFW_KEY_UP: return "UP";
            case GLFW.GLFW_KEY_DOWN: return "DOWN";
            case GLFW.GLFW_KEY_LEFT: return "LEFT";
            case GLFW.GLFW_KEY_RIGHT: return "RIGHT";
            default:
                break;
        }
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) {
            return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        }
        String n = GLFW.glfwGetKeyName(k, 0);
        return n != null ? n.toUpperCase() : "KEY" + k;
    }
}
